﻿using System;

namespace SDK_small
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("using System;

public class Class1
        {
            public Class1(<pre>
HTTrack version 3.49-2


            usage: httrack &lt; URLs&gt; [-option]
            [+&lt;URL_FILTER&gt;]
            [-&lt;URL_FILTER&gt;]
            [+&lt;mime:MIME_FILTER&gt;]
            [-&lt;mime:MIME_FILTER&gt;]
            with options listed below: (* is the default value)

General options:
  O path for mirror/logfiles+cache(-O path_mirror[, path_cache_and_logfiles]) (--path &lt;param&gt;)

Action options:
  w* mirror web sites(--mirror)
  W mirror web sites, semi-automatic(asks questions) (--mirror-wizard)
  g just get files(saved in the current directory) (--get-files)
  i  continue an interrupted mirror using the cache(--continue)
  Y mirror ALL links located in the first level pages(mirror links) (--mirrorlinks)

Proxy options:
  P proxy use(-P proxy:port or -P user:pass @proxy:port) (--proxy &lt;param&gt;)
 %f* use proxy for ftp(f0 don&apos; t use) (--httpproxy-ftp[= N])
 %b use this local hostname to make/send requests (-%b hostname) (--bind &lt; param&gt;)

Limits options:
  rN set the mirror depth to N(*r9999)(--depth[= N])
 % eN set the external links depth to N(* % e0)(--ext - depth[= N])
  mN maximum file length for a non-html file(--max - files[= N])
  mN, N2 maximum file length for non html (N) and html(N2)


   MN maximum overall size that can be uploaded / scanned(--max - size[= N])


   EN maximum mirror time in seconds(60 = 1 minute, 3600 = 1 hour)(--max - time[= N])


   AN maximum transfer rate in bytes / seconds(1000 = 1KB / s max)(--max - rate[= N])
  % cN maximum number of connections / seconds(*% c10)(--connection - per - second[= N])


   GN pause transfer if N bytes reached, and wait until lock file is deleted(--max - pause[= N])

 Flow control:
        cN number of multiple connections(*c8)(--sockets[= N])
  TN timeout, number of seconds after a non - responding link is shutdown(--timeout[= N])
    RN number of retries, in case of timeout or non-fatal errors(*R1)(--retries[= N])
  JN traffic jam control, minimum transfert rate(bytes/ seconds) tolerated for a link (--min - rate[= N])
  HN host is abandonned if: 0 = never, 1 = timeout, 2 = slow, 3 = timeout or slow(--host - control[= N])

Links options:
 % P * extended parsing, attempt to parse all links, even in unknown tags or Javascript(% P0 don & apos; t use) (--extended - parsing[= N])
  n get non - html files & apos; near & apos; an html file(ex: an image located outside)(--near)
  t test all URLs(even forbidden ones) (--test)
% L & lt; file & gt; add all URL located in this text file(one URL per line) (--list & lt; param & gt;)
 % S & lt; file & gt; add all scan rules located in this text file(one scan rule per line) (--urllist & lt; param & gt;)

Build options:
  NN structure type(0 * original structure, 1 +: see below)(--structure[= N])
     or user defined structure(-N & quot;% h % p /% n % q.% t & quot;)
 % N  delayed type check, don & apos; t make any link test but wait for files download to start instead(experimental)(% N0 don & apos; t use, % N1 use for unknown extensions, * % N2 always use)
 % D  cached delayed type check, don&apos; t wait for remote type during updates, to speedup them(% D0 wait, * % D1 don & apos; t wait) (--cached - delayed - type - check)
       % M  generate a RFC MIME-encapsulated full - archive(.mht)(--mime - html)
  LN long names(L1*long names / L0 8 - 3 conversion / L2 ISO9660 compatible) (--long - names[= N])
  KN keep original links(e.g.http://www.adr/link) (K0 *relative link, K absolute links, K4 original links, K3 absolute URI links, K5 transparent proxy link) (--keep-links[=N])
  x replace external html links by error pages(--replace - external)
 % x  do not include any password for external password protected websites (% x0 include) (--disable - passwords)
   % q * include query string for local files (useless, for information purpose only) (% q0 don & apos; t include) (--include - query - string)
  o* generate output html file in case of error(404..) (o0 don & apos; t generate) (--generate - errors)
  X* purge old files after update(X0 keep delete) (--purge - old[= N])
% p  preserve html files & apos;as is &apos; (identical to & apos; -K4 -% F & quot; &quot; &apos;) (--preserve)
         % T  links conversion to UTF-8(--utf8 - conversion)

Spider options:
  bN accept cookies in cookies.txt(0 =do not accept,*1 = accept) (--cookies[= N])
  u check document type if unknown(cgi, asp..)(u0 don & apos; t check, *u1 check but /, u2 check always) (--check - type[= N])
  j* parse Java Classes(j0 don&apos; t parse, bitmask: | 1 parse default, | 2 don & apos; t parse .class |4 don&apos;t parse.js |8 don&apos; t be aggressive) (--parse-java[= N])
  sN follow robots.txt and meta robots tags(0=never,1=sometimes,* 2=always, 3=always (even strict rules)) (--robots[= N])
 %h force HTTP/1.0 requests(reduce update features, only for old servers or proxies) (--http-10)
 %k use keep-alive if possible, greately reducing latency for small files and test requests(%k0 don&apos; t use) (--keep-alive)
 %B tolerant requests(accept bogus responses on some servers, but not standard!) (--tolerant)
 %s update hacks: various hacks to limit re-transfers when updating(identical size, bogus response..) (--updatehack)
 %u url hacks: various hacks to limit duplicate URLs(strip //, www.foo.com==foo.com..) (--urlhack)
 %A assume that a type (cgi, asp..) is always linked with a mime type(-%A php3, cgi= text / html; dat,bin=application/x-zip) (--assume &lt;param&gt;)
     shortcut: &apos;--assume standard&apos; is equivalent to -%A php2 php3 php4 php cgi asp jsp pl cfm nsf=text/html
     can also be used to force a specific file type: --assume foo.cgi=text/html
 @iN internet protocol (0=both ipv6+ipv4, 4=ipv4 only, 6=ipv6 only) (--protocol[= N])
 %w disable a specific external mime module(-%w htsswf -%w htsjava) (--disable-module &lt;param&gt;)

Browser ID:
  F user-agent field sent in HTTP headers(-F &quot; user-agent name&quot;) (--user-agent &lt;param&gt;)
 %R  default referer field sent in HTTP headers(--referer &lt; param&gt;)
 %E from email address sent in HTTP headers(--from &lt; param&gt;)
 %F footer string in Html code(-%F &quot; Mirrored[from host % s[file % s[at % s]]]&quot; (--footer &lt;param&gt;)
 %l preffered language(-%l &quot; fr, en, jp, *&quot; (--language &lt;param&gt;)
 %a accepted formats(-%a &quot; text/html,image/png;q=0.9,*/*;q=0.1&quot; (--accept &lt;param&gt;)
 %X  additional HTTP header line (-%X &quot;X-Magic: 42&quot; (--headers &lt;param&gt;)

Log, index, cache
  C  create/use a cache for updates and retries (C0 no cache,C1 cache is prioritary,* C2 test update before) (--cache[=N])
  k  store all files in cache (not useful if files on disk) (--store-all-in-cache)
 %n  do not re-download locally erased files (--do-not-recatch)
 %v  display on screen filenames downloaded (in realtime) - * %v1 short version - %v2 full animation (--display)
  Q  no log - quiet mode (--do-not-log)
  q  no questions - quiet mode (--quiet)
  z  log - extra infos (--extra-log)
  Z  log - debug (--debug-log)
  v  log on screen (--verbose)
  f *log in files (--file-log)
  f2 one single log file (--single-log)
  I *make an index (I0 don&apos;t make) (--index)
 %i  make a top index for a project folder (* %i0 don&apos;t make) (--build-top-index)
 %I  make an searchable index for this mirror (* %I0 don&apos;t make) (--search-index)

Expert options:
  pN priority mode: (* p3) (--priority[=N])
      p0 just scan, don&apos;t save anything (for checking links)
      p1 save only html files
      p2 save only non html files
     *p3 save all files
      p7 get html files before, then treat other files
  S  stay on the same directory (--stay-on-same-dir)
  D *can only go down into subdirs (--can-go-down)
  U  can only go to upper directories (--can-go-up)
  B  can both go up&amp;down into the directory structure (--can-go-up-and-down)
  a *stay on the same address (--stay-on-same-address)
  d  stay on the same principal domain (--stay-on-same-domain)
  l  stay on the same TLD (eg: .com) (--stay-on-same-tld)
  e  go everywhere on the web (--go-everywhere)
 %H  debug HTTP headers in logfile (--debug-headers)

Guru options: (do NOT use if possible)
 #X *use optimized engine (limited memory boundary checks) (--fast-engine)
 #0  filter test (-#0 &apos;*.gif&apos; &apos;www.bar.com/foo.gif&apos;) (--debug-testfilters &lt;param&gt;)
 #1  simplify test (-#1 ./foo/bar/../foobar)
 #2  type test (-#2 /foo/bar.php)
 #C  cache list (-#C &apos;*.com/spider*.gif&apos; (--debug-cache &lt;param&gt;)
 #R  cache repair (damaged cache) (--repair-cache)
 #d  debug parser (--debug-parsing)
 #E  extract new.zip cache meta-data in meta.zip
 #f  always flush log files (--advanced-flushlogs)
 #FN maximum number of filters (--advanced-maxfilters[=N])
 #h  version info (--version)
 #K  scan stdin (debug) (--debug-scanstdin)
 #L  maximum number of links (-#L1000000) (--advanced-maxlinks[=N])
 #p  display ugly progress information (--advanced-progressinfo)
 #P  catch URL (--catch-url)
 #R  old FTP routines (debug) (--repair-cache)
 #T  generate transfer ops. log every minutes (--debug-xfrstats)
 #u  wait time (--advanced-wait)
 #Z  generate transfer rate statictics every minutes (--debug-ratestats)

Dangerous options: (do NOT use unless you exactly know what you are doing)
 %!  bypass built-in security limits aimed to avoid bandwidth abuses (bandwidth, simultaneous connections) (--disable-security-limits)
     IMPORTANT NOTE: DANGEROUS OPTION, ONLY SUITABLE FOR EXPERTS
                     USE IT WITH EXTREME CARE

Command-line specific options:
  V execute system command after each files ($0 is the filename: -V &quot;rm \$0&quot;) (--userdef-cmd &lt;param&gt;)
 %W use an external library function as a wrapper (-%W myfoo.so[,myparameters]) (--callback &lt;param&gt;)

Details: Option N
  N0 Site-structure (default)
  N1 HTML in web/, images/other files in web/images/
  N2 HTML in web/HTML, images/other in web/images
  N3 HTML in web/,  images/other in web/
  N4 HTML in web/, images/other in web/xxx, where xxx is the file extension (all gif will be placed onto web/gif, for example)
  N5 Images/other in web/xxx and HTML in web/HTML
  N99 All files in web/, with random names (gadget !)
  N100 Site-structure, without www.domain.xxx/
  N101 Identical to N1 exept that &quot;web&quot; is replaced by the site&apos;s name
  N102 Identical to N2 exept that &quot;web&quot; is replaced by the site&apos;s name
  N103 Identical to N3 exept that &quot;web&quot; is replaced by the site&apos;s name
  N104 Identical to N4 exept that &quot;web&quot; is replaced by the site&apos;s name
  N105 Identical to N5 exept that &quot;web&quot; is replaced by the site&apos;s name
  N199 Identical to N99 exept that &quot;web&quot; is replaced by the site&apos;s name
  N1001 Identical to N1 exept that there is no &quot;web&quot; directory
  N1002 Identical to N2 exept that there is no &quot;web&quot; directory
  N1003 Identical to N3 exept that there is no &quot;web&quot; directory (option set for g option)
  N1004 Identical to N4 exept that there is no &quot;web&quot; directory
  N1005 Identical to N5 exept that there is no &quot;web&quot; directory
  N1099 Identical to N99 exept that there is no &quot;web&quot; directory
Details: User-defined option N
  &apos;%n&apos; Name of file without file type (ex: image)
  &apos;%N&apos; Name of file, including file type (ex: image.gif)
  &apos;%t&apos; File type (ex: gif)
  &apos;%p&apos; Path [without ending /] (ex: /someimages)
  &apos;%h&apos; Host name (ex: www.someweb.com)
  &apos;%M&apos; URL MD5 (128 bits, 32 ascii bytes)
  &apos;%Q&apos; query string MD5 (128 bits, 32 ascii bytes)
  &apos;%k&apos; full query string
  &apos;%r&apos; protocol name (ex: http)
  &apos;%q&apos; small query string MD5 (16 bits, 4 ascii bytes)
     &apos;%s?&apos; Short name version (ex: %sN)
  &apos;%[param]&apos; param variable in query string
  &apos;%[param:before:after:empty:notfound]&apos; advanced variable extraction
Details: User-defined option N and advanced variable extraction
   %[param:before:after:empty:notfound]
   param : parameter name
   before : string to prepend if the parameter was found
   after : string to append if the parameter was found
   notfound : string replacement if the parameter could not be found
   empty : string replacement if the parameter was empty
   all fields, except the first one (the parameter name), can be empty

Details: Option K
  K0  foo.cgi?q=45  -&gt;  foo4B54.html?q=45 (relative URI, default)
  K                 -&gt;  http://www.foobar.com/folder/foo.cgi?q=45 (absolute URL) (--keep-links[=N])
  K3                -&gt;  /folder/foo.cgi?q=45 (absolute URI)
  K4                -&gt;  foo.cgi?q=45 (original URL)
  K5                -&gt;  http://www.foobar.com/folder/foo4B54.html?q=45 (transparent proxy URL)

Shortcuts:
--mirror      &lt;URLs&gt; *make a mirror of site(s) (default)
--get         &lt;URLs&gt;  get the files indicated, do not seek other URLs (-qg)
--list   &lt;text file&gt;  add all URL located in this text file (-%L)
--mirrorlinks &lt;URLs&gt;  mirror all links in 1st level pages (-Y)
--testlinks   &lt;URLs&gt;  test links in pages (-r1p0C0I0t)
--spider      &lt;URLs&gt;  spider site(s), to test links: reports Errors &amp; Warnings (-p0C0I0t)
--testsite    &lt;URLs&gt;  identical to --spider
--skeleton    &lt;URLs&gt;  make a mirror, but gets only html files (-p1)
--update              update a mirror, without confirmation (-iC2)
--continue            continue a mirror, without confirmation (-iC1)

--catchurl            create a temporary proxy to capture an URL or a form post URL
--clean               erase cache &amp; log files

--http10              force http/1.0 requests (-%h)

Details: Option %W: External callbacks prototypes
see htsdefines.h

example: httrack www.someweb.com/bob/
means:   mirror site www.someweb.com/bob/ and only this site

example: httrack www.someweb.com/bob/ www.anothertest.com/mike/ +*.com/*.jpg -mime:application/*
means:   mirror the two sites together (with shared links) and accept any .jpg files on .com sites

example: httrack www.someweb.com/bob/bobby.html +* -r6
means get all files starting from bobby.html, with 6 link-depth, and possibility of going everywhere on the web

example: httrack www.someweb.com/bob/bobby.html --spider -P proxy.myhost.com:8080
runs the spider on www.someweb.com/bob/bobby.html using a proxy

example: httrack --update
updates a mirror in the current folder

example: httrack
will bring you to the interactive mode

example: httrack --continue
continues a mirror in the current folder

HTTrack version 3.49-2
Copyright (C) 1998-2017 Xavier Roche and other contributors
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set -./otus.op
bash: set: -.: érvénytelen kapcsoló
set: használat: set [--abefhkmnptuvxBCHP] [-o beállításnév] [--] [arg ...]
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;2&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=-./otus.op
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs] pm|gif|jp? (e) g|mp3|mp? (e) g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.? (t) bz? (2)&quot; [dragon]=&quot;!*@(.@(mp?(e) g|MP? (E) G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m? (p)4[av]|M? (P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t? (s)|M2T? (S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo] d|M[EO] D|s[3t] m|S[3T] M|it|IT|xm|XM|iso|ISO)|+([0 - 9]).@(vdr|VDR))? (.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs] pm|gif|jp? (e) g|mp3|mp? (e) g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e) ps|pdf)&quot; [gpdf]=&quot;!*.[pf] df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la) tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs] m|dmf|far|it|mdl|m[eo] d|mid? (i)|mt[2m]|oct|okt? (a)|p[st] m|s[3t] m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e) ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e) ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs] pm|gif|jp? (e) g|mp3|mp? (e) g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.? (t) bz? (2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs] pm|gif|jp? (e) g|mp3|mp? (e) g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la) tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs] pm|gif|jp? (e) g|mp3|mp? (e) g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la) tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs] pm|gif|jp? (e) g|mp3|mp? (e) g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)? (.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp? (e) g? (2)|j2[ck]|jp[2f]|tif? (f)|png|p[bgp] m|bmp|x[bp] m|rle|rgb|pcx|fits|pm|? (e) ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH] [tT] [mM]? ([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t] m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)? (.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)? (.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la) tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e) ps|? (E) PS|pdf|PDF)? (.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd] z|t[ag] z)&quot; [pbunzip2]=&quot;!*.? (t) bz? (2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|? (d) patch)? (.@([gx] z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH] [tT] [mM]? ([lL])|[pP] [dD] [fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH] [tT] [mM]? ([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs] pm|gif|jp? (e) g|mp3|mp? (e) g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la) tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/
}&quot; compfile;
    [[ -n $cmd]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref()
{
    local exclude i j line ref;
    if [[-n $1]]; then
      exclude = &quot;${
        1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
        printf - v & quot;$3 & quot; % s & quot;$COMP_CWORD & quot; ;
        if [[-n $exclude]]; then
          line =$COMP_LINE;
        for ((i = 0, j = 0; i & lt; ${#COMP_WORDS[@]}; i++, j++))
        do
                while [[ $i - gt 0 & amp;&amp; ${ COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]] * ]] &amp; &amp; ((j & gt;= 2 )) &amp; &amp; ((j--));
        ref= &quot;$2[$j] & quot; ;
        printf - v & quot;$ref&quot; % s & quot;${ !ref}${ COMP_WORDS[i]}
        &quot; ;
                [[ $i == $COMP_CWORD]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups()
{
    if _complete_as_root; then
        local IFS = &apos;
    &apos; ;
    COMPREPLY = ($(compgen - g-- & quot;$1 & quot; ));
    else
        local IFS = &apos;
    &apos; ;
    COMPREPLY = ($(compgen - W & quot;$(id - Gn 2 & gt;/ dev / null || groups 2 & gt;/ dev / null )&quot; --&quot;$1 & quot; ));
    fi
}
_allowed_users()
{
    if _complete_as_root; then
        local IFS = &apos;
    &apos; ;
    COMPREPLY = ($(compgen - u-- & quot;${ 1:-$cur}
    &quot; ));
    else
        local IFS = &apos;
    &apos; ;
    COMPREPLY = ($(compgen - W & quot;$(id - un 2 & gt;/ dev / null || whoami 2 & gt;/ dev / null )&quot; --&quot;${ 1:-$cur}
    &quot; ));
    fi
}
_available_interfaces()
{
    local PATH =$PATH:/ sbin;
    COMPREPLY = ($( {
        if [[ ${ 1:-} == -w ]]; then
             iwconfig
          elif[[ ${ 1:-} == -a ]]; then
              ifconfig || ip link show up
        else
            ifconfig - a || ip link show
          fi
      }
    2 & gt;/ dev / null | awk & apos;/ ^[^ \t] / { if ($1 ~ / ^[0 - 9] +:/) { print $2 } else { print $1 } }
    &apos; ));
    COMPREPLY = ($(compgen - W & apos;${ COMPREPLY[@] /%[[:punct:]]/}
    &apos; --&quot;$cur & quot; ))
}
_cd()
{
    local cur prev words cword;
    _init_completion || return;
    local IFS = &apos;
    &apos; i j k;
    compopt - o filenames;
    if [[-z & quot;${ CDPATH: -}
    &quot; || &quot;$cur & quot; == ? (.) ? (.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/& quot; ]]; then
             COMPREPLY[0] = &quot;${ i}/ &quot; ;
    fi;
    fi;
    return
}
_cd_devices()
{
    COMPREPLY += ($(compgen - f - d - X & quot; !*/? ([amrs])cd * &quot; --&quot;${ cur: -/ dev /}
    &quot; ))
}
_command()
{
    local offset i;
    offset = 1;
    for ((i = 1; i & lt;= COMP_CWORD; i++ ))
    do
        if [[&quot;${ COMP_WORDS[i]}
    &quot; != -* ]]; then
offset =$i;
    break;
    fi;
    done;
    _command_offset $offset
}
_command_offset()
{
    local word_offset =$1 i j;
    for ((i = 0; i & lt; $word_offset; i++ ))
    do
        for ((j = 0; j & lt;= ${#COMP_LINE}; j++ ))
        do
            [[&quot;$COMP_LINE & quot; == &quot;${ COMP_WORDS[i]}
            &quot; * ]] &amp; &amp; break;
            COMP_LINE =${ COMP_LINE: 1};
            ((COMP_POINT--));
            done;
            COMP_LINE =${
                COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT -=${#COMP_WORDS[i]}));
    done;
                    for ((i = 0; i & lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i] =${ COMP_WORDS[i +$word_offset]};
    done;
    for ((i; i & lt;= COMP_CWORD; i++ ))
    do
        unset & apos;COMP_WORDS[i] & apos; ;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY = ();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD - eq 0]]; then
        local IFS = &apos;
    &apos; ;
    compopt - o filenames;
    COMPREPLY = ($(compgen - d - c-- & quot;$cur & quot; ));
    else
        local cmd =${ COMP_WORDS[0]}
    compcmd =${ COMP_WORDS[0]};
    local cspec =$(complete - p $cmd 2 & gt;/ dev / null );
    if [[!-n $cspec & amp; &amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec]]; then
compcmd =${cmd##*/};
            _completion_loader $compcmd;
            cspec=$(complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt =${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec =${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set metha.set -.obs.log
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;0&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=-.obs.log
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.?(t)bz?(2)&quot; [dragon]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e)ps|pdf)&quot; [gpdf]=&quot;!*.[pf]df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e)ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e)ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.?(t)bz?(2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp?(e)g?(2)|j2[ck]|jp[2f]|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|?(e)ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t]m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)?(.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [pbunzip2]=&quot;!*.?(t)bz?(2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|?(d)patch)?(.@([gx]z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/}&quot; compfile;
    [[ -n $cmd ]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref () 
{ 
    local exclude i j line ref;
    if [[ -n $1 ]]; then
        exclude=&quot;${1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
    printf -v &quot;$3&quot; %s &quot;$COMP_CWORD&quot;;
    if [[ -n $exclude ]]; then
        line=$COMP_LINE;
        for ((i=0, j=0; i &lt; ${#COMP_WORDS[@]}; i++, j++))
        do
            while [[ $i -gt 0 &amp;&amp; ${COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]]* ]] &amp;&amp; (( j &gt;= 2 )) &amp;&amp; ((j--));
                ref=&quot;$2[$j]&quot;;
                printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
                [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -g -- &quot;$1&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -Gn 2&gt;/dev/null || groups 2&gt;/dev/null )&quot; -- &quot;$1&quot; ));
    fi
}
_allowed_users () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -u -- &quot;${1:-$cur}&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -un 2&gt;/dev/null || whoami 2&gt;/dev/null )&quot; -- &quot;${1:-$cur}&quot; ));
    fi
}
_available_interfaces () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY=($( {
        if [[ ${1:-} == -w ]]; then
            iwconfig
        elif [[ ${1:-} == -a ]]; then
            ifconfig || ip link show up
        else
            ifconfig -a || ip link show
        fi
    } 2&gt;/dev/null | awk         &apos;/^[^ \t]/ { if ($1 ~ /^[0-9]+:/) { print $2 } else { print $1 } }&apos; ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]/%[[:punct:]]/}&apos; -- &quot;$cur&quot; ))
}
_cd () 
{ 
    local cur prev words cword;
    _init_completion || return;
    local IFS=&apos;
&apos; i j k;
    compopt -o filenames;
    if [[ -z &quot;${CDPATH:-}&quot; || &quot;$cur&quot; == ?(.)?(.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/&quot; ]]; then
            COMPREPLY[0]=&quot;${i}/&quot;;
        fi;
    fi;
    return
}
_cd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?([amrs])cd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_command () 
{ 
    local offset i;
    offset=1;
    for ((i=1; i &lt;= COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            offset=$i;
            break;
        fi;
    done;
    _command_offset $offset
}
_command_offset () 
{ 
    local word_offset=$1 i j;
    for ((i=0; i &lt; $word_offset; i++ ))
    do
        for ((j=0; j &lt;= ${#COMP_LINE}; j++ ))
        do
            [[ &quot;$COMP_LINE&quot; == &quot;${COMP_WORDS[i]}&quot;* ]] &amp;&amp; break;
            COMP_LINE=${COMP_LINE:1};
            ((COMP_POINT--));
        done;
        COMP_LINE=${COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT-=${#COMP_WORDS[i]}));
    done;
    for ((i=0; i &lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i]=${COMP_WORDS[i+$word_offset]};
    done;
    for ((i; i &lt;= COMP_CWORD; i++ ))
    do
        unset &apos;COMP_WORDS[i]&apos;;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY=();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD -eq 0 ]]; then
        local IFS=&apos;
&apos;;
        compopt -o filenames;
        COMPREPLY=($( compgen -d -c -- &quot;$cur&quot; ));
    else
        local cmd=${COMP_WORDS[0]} compcmd=${COMP_WORDS[0]};
        local cspec=$( complete -p $cmd 2&gt;/dev/null );
        if [[ ! -n $cspec &amp;&amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec ]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec ]]; then
            compcmd=${cmd##*/};
            _completion_loader $compcmd;
            cspec=$( complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec ]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt=${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec=${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set }brute
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;0&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=&apos;}brute&apos;
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.?(t)bz?(2)&quot; [dragon]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e)ps|pdf)&quot; [gpdf]=&quot;!*.[pf]df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e)ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e)ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.?(t)bz?(2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp?(e)g?(2)|j2[ck]|jp[2f]|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|?(e)ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t]m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)?(.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [pbunzip2]=&quot;!*.?(t)bz?(2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|?(d)patch)?(.@([gx]z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/}&quot; compfile;
    [[ -n $cmd ]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref () 
{ 
    local exclude i j line ref;
    if [[ -n $1 ]]; then
        exclude=&quot;${1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
    printf -v &quot;$3&quot; %s &quot;$COMP_CWORD&quot;;
    if [[ -n $exclude ]]; then
        line=$COMP_LINE;
        for ((i=0, j=0; i &lt; ${#COMP_WORDS[@]}; i++, j++))
        do
            while [[ $i -gt 0 &amp;&amp; ${COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]]* ]] &amp;&amp; (( j &gt;= 2 )) &amp;&amp; ((j--));
                ref=&quot;$2[$j]&quot;;
                printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
                [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -g -- &quot;$1&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -Gn 2&gt;/dev/null || groups 2&gt;/dev/null )&quot; -- &quot;$1&quot; ));
    fi
}
_allowed_users () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -u -- &quot;${1:-$cur}&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -un 2&gt;/dev/null || whoami 2&gt;/dev/null )&quot; -- &quot;${1:-$cur}&quot; ));
    fi
}
_available_interfaces () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY=($( {
        if [[ ${1:-} == -w ]]; then
            iwconfig
        elif [[ ${1:-} == -a ]]; then
            ifconfig || ip link show up
        else
            ifconfig -a || ip link show
        fi
    } 2&gt;/dev/null | awk         &apos;/^[^ \t]/ { if ($1 ~ /^[0-9]+:/) { print $2 } else { print $1 } }&apos; ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]/%[[:punct:]]/}&apos; -- &quot;$cur&quot; ))
}
_cd () 
{ 
    local cur prev words cword;
    _init_completion || return;
    local IFS=&apos;
&apos; i j k;
    compopt -o filenames;
    if [[ -z &quot;${CDPATH:-}&quot; || &quot;$cur&quot; == ?(.)?(.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/&quot; ]]; then
            COMPREPLY[0]=&quot;${i}/&quot;;
        fi;
    fi;
    return
}
_cd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?([amrs])cd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_command () 
{ 
    local offset i;
    offset=1;
    for ((i=1; i &lt;= COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            offset=$i;
            break;
        fi;
    done;
    _command_offset $offset
}
_command_offset () 
{ 
    local word_offset=$1 i j;
    for ((i=0; i &lt; $word_offset; i++ ))
    do
        for ((j=0; j &lt;= ${#COMP_LINE}; j++ ))
        do
            [[ &quot;$COMP_LINE&quot; == &quot;${COMP_WORDS[i]}&quot;* ]] &amp;&amp; break;
            COMP_LINE=${COMP_LINE:1};
            ((COMP_POINT--));
        done;
        COMP_LINE=${COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT-=${#COMP_WORDS[i]}));
    done;
    for ((i=0; i &lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i]=${COMP_WORDS[i+$word_offset]};
    done;
    for ((i; i &lt;= COMP_CWORD; i++ ))
    do
        unset &apos;COMP_WORDS[i]&apos;;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY=();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD -eq 0 ]]; then
        local IFS=&apos;
&apos;;
        compopt -o filenames;
        COMPREPLY=($( compgen -d -c -- &quot;$cur&quot; ));
    else
        local cmd=${COMP_WORDS[0]} compcmd=${COMP_WORDS[0]};
        local cspec=$( complete -p $cmd 2&gt;/dev/null );
        if [[ ! -n $cspec &amp;&amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec ]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec ]]; then
            compcmd=${cmd##*/};
            _completion_loader $compcmd;
            cspec=$( complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec ]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt=${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec=${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set }config{execute}&lt;delete /storage.format _else.world
bash: delete: Nincs ilyen fájl vagy könyvtár
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;1&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=_else.world
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.?(t)bz?(2)&quot; [dragon]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e)ps|pdf)&quot; [gpdf]=&quot;!*.[pf]df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e)ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e)ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.?(t)bz?(2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp?(e)g?(2)|j2[ck]|jp[2f]|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|?(e)ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t]m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)?(.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [pbunzip2]=&quot;!*.?(t)bz?(2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|?(d)patch)?(.@([gx]z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/}&quot; compfile;
    [[ -n $cmd ]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref () 
{ 
    local exclude i j line ref;
    if [[ -n $1 ]]; then
        exclude=&quot;${1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
    printf -v &quot;$3&quot; %s &quot;$COMP_CWORD&quot;;
    if [[ -n $exclude ]]; then
        line=$COMP_LINE;
        for ((i=0, j=0; i &lt; ${#COMP_WORDS[@]}; i++, j++))
        do
            while [[ $i -gt 0 &amp;&amp; ${COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]]* ]] &amp;&amp; (( j &gt;= 2 )) &amp;&amp; ((j--));
                ref=&quot;$2[$j]&quot;;
                printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
                [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -g -- &quot;$1&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -Gn 2&gt;/dev/null || groups 2&gt;/dev/null )&quot; -- &quot;$1&quot; ));
    fi
}
_allowed_users () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -u -- &quot;${1:-$cur}&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -un 2&gt;/dev/null || whoami 2&gt;/dev/null )&quot; -- &quot;${1:-$cur}&quot; ));
    fi
}
_available_interfaces () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY=($( {
        if [[ ${1:-} == -w ]]; then
            iwconfig
        elif [[ ${1:-} == -a ]]; then
            ifconfig || ip link show up
        else
            ifconfig -a || ip link show
        fi
    } 2&gt;/dev/null | awk         &apos;/^[^ \t]/ { if ($1 ~ /^[0-9]+:/) { print $2 } else { print $1 } }&apos; ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]/%[[:punct:]]/}&apos; -- &quot;$cur&quot; ))
}
_cd () 
{ 
    local cur prev words cword;
    _init_completion || return;
    local IFS=&apos;
&apos; i j k;
    compopt -o filenames;
    if [[ -z &quot;${CDPATH:-}&quot; || &quot;$cur&quot; == ?(.)?(.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/&quot; ]]; then
            COMPREPLY[0]=&quot;${i}/&quot;;
        fi;
    fi;
    return
}
_cd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?([amrs])cd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_command () 
{ 
    local offset i;
    offset=1;
    for ((i=1; i &lt;= COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            offset=$i;
            break;
        fi;
    done;
    _command_offset $offset
}
_command_offset () 
{ 
    local word_offset=$1 i j;
    for ((i=0; i &lt; $word_offset; i++ ))
    do
        for ((j=0; j &lt;= ${#COMP_LINE}; j++ ))
        do
            [[ &quot;$COMP_LINE&quot; == &quot;${COMP_WORDS[i]}&quot;* ]] &amp;&amp; break;
            COMP_LINE=${COMP_LINE:1};
            ((COMP_POINT--));
        done;
        COMP_LINE=${COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT-=${#COMP_WORDS[i]}));
    done;
    for ((i=0; i &lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i]=${COMP_WORDS[i+$word_offset]};
    done;
    for ((i; i &lt;= COMP_CWORD; i++ ))
    do
        unset &apos;COMP_WORDS[i]&apos;;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY=();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD -eq 0 ]]; then
        local IFS=&apos;
&apos;;
        compopt -o filenames;
        COMPREPLY=($( compgen -d -c -- &quot;$cur&quot; ));
    else
        local cmd=${COMP_WORDS[0]} compcmd=${COMP_WORDS[0]};
        local cspec=$( complete -p $cmd 2&gt;/dev/null );
        if [[ ! -n $cspec &amp;&amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec ]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec ]]; then
            compcmd=${cmd##*/};
            _completion_loader $compcmd;
            cspec=$( complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec ]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt=${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec=${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set  &lt;exclecuder -.brute.if;else
bash: szintaktikai hiba „else” váratlan token közelében
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;0&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=set
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.?(t)bz?(2)&quot; [dragon]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e)ps|pdf)&quot; [gpdf]=&quot;!*.[pf]df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e)ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e)ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.?(t)bz?(2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp?(e)g?(2)|j2[ck]|jp[2f]|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|?(e)ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t]m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)?(.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [pbunzip2]=&quot;!*.?(t)bz?(2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|?(d)patch)?(.@([gx]z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/}&quot; compfile;
    [[ -n $cmd ]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref () 
{ 
    local exclude i j line ref;
    if [[ -n $1 ]]; then
        exclude=&quot;${1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
    printf -v &quot;$3&quot; %s &quot;$COMP_CWORD&quot;;
    if [[ -n $exclude ]]; then
        line=$COMP_LINE;
        for ((i=0, j=0; i &lt; ${#COMP_WORDS[@]}; i++, j++))
        do
            while [[ $i -gt 0 &amp;&amp; ${COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]]* ]] &amp;&amp; (( j &gt;= 2 )) &amp;&amp; ((j--));
                ref=&quot;$2[$j]&quot;;
                printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
                [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -g -- &quot;$1&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -Gn 2&gt;/dev/null || groups 2&gt;/dev/null )&quot; -- &quot;$1&quot; ));
    fi
}
_allowed_users () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -u -- &quot;${1:-$cur}&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -un 2&gt;/dev/null || whoami 2&gt;/dev/null )&quot; -- &quot;${1:-$cur}&quot; ));
    fi
}
_available_interfaces () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY=($( {
        if [[ ${1:-} == -w ]]; then
            iwconfig
        elif [[ ${1:-} == -a ]]; then
            ifconfig || ip link show up
        else
            ifconfig -a || ip link show
        fi
    } 2&gt;/dev/null | awk         &apos;/^[^ \t]/ { if ($1 ~ /^[0-9]+:/) { print $2 } else { print $1 } }&apos; ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]/%[[:punct:]]/}&apos; -- &quot;$cur&quot; ))
}
_cd () 
{ 
    local cur prev words cword;
    _init_completion || return;
    local IFS=&apos;
&apos; i j k;
    compopt -o filenames;
    if [[ -z &quot;${CDPATH:-}&quot; || &quot;$cur&quot; == ?(.)?(.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/&quot; ]]; then
            COMPREPLY[0]=&quot;${i}/&quot;;
        fi;
    fi;
    return
}
_cd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?([amrs])cd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_command () 
{ 
    local offset i;
    offset=1;
    for ((i=1; i &lt;= COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            offset=$i;
            break;
        fi;
    done;
    _command_offset $offset
}
_command_offset () 
{ 
    local word_offset=$1 i j;
    for ((i=0; i &lt; $word_offset; i++ ))
    do
        for ((j=0; j &lt;= ${#COMP_LINE}; j++ ))
        do
            [[ &quot;$COMP_LINE&quot; == &quot;${COMP_WORDS[i]}&quot;* ]] &amp;&amp; break;
            COMP_LINE=${COMP_LINE:1};
            ((COMP_POINT--));
        done;
        COMP_LINE=${COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT-=${#COMP_WORDS[i]}));
    done;
    for ((i=0; i &lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i]=${COMP_WORDS[i+$word_offset]};
    done;
    for ((i; i &lt;= COMP_CWORD; i++ ))
    do
        unset &apos;COMP_WORDS[i]&apos;;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY=();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD -eq 0 ]]; then
        local IFS=&apos;
&apos;;
        compopt -o filenames;
        COMPREPLY=($( compgen -d -c -- &quot;$cur&quot; ));
    else
        local cmd=${COMP_WORDS[0]} compcmd=${COMP_WORDS[0]};
        local cspec=$( complete -p $cmd 2&gt;/dev/null );
        if [[ ! -n $cspec &amp;&amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec ]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec ]]; then
            compcmd=${cmd##*/};
            _completion_loader $compcmd;
            cspec=$( complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec ]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt=${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec=${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># history
   60  set blwhole.brute accident.asia .-frog 190.23.76.121:whole.b -.hibs
   61  set
   62  set vils.trog
   63  set
   64  set y.hibana
   65  set6
   66  set .loi :star:A21.10 .-E41 lew.car :api ./bw -white.shark
   67  set sledge.is defected:hibana /route:175.191.56.87.2.7 /.blackhawk
   68  set
   69  set sledge
   70  set
   71  set analitics
   72  set hibana
   73  set
   74  set anonymous.rt
   75  set
   76  set duel.analogon :freey .acklod /deyamahl.foot:RDT.x.bat _self.test
   77  set
   78  exit
   79  set sledge.is defected:hibana /route:175.191.56.87.2.7 /.blackhawk
   80  set
   81  set nulo
   82  set
   83  set riff
   84  set open.port well.delete hb.A2 _E12:33.04 -cancel .operator.del
   85  set pell.close
   86  set
   87  set root.diskself :open .194.20.34.2 -.setting.if -else _r.2 .nomad
   88  set before.reference .backdoor :open.lead /disk.capacity :during.r2
   89  set r.2/fad.9 _else.if method:repo ...DATA.DAT/delete.del -.dll
   90  set
   91  set surg
   92  set
   93  set olmech
   94  set
   95  set riff
   96  set
   97  exit
   98  set frz.vigil :capz .dlts /A6.N1.N8-.01 .2 /nute :4200.del
   99  set
  100  set odd.shark _revenger.eupa :tati /191.2.34.72:open
  101  set read.before -right .add:europa .council:leash .lash
  102  set lash.A4.7G.34B.B01 .common -build.task /reader.bulo
  103  set bullet.frog _right :eleven.port /fad .2/beta.ride _shark
  104  set
  105  set red.del
  106  set
  107  set event.rog /date.if-now :represent.RT //DATA.DAT -projector.run
  108  set else.if -route .open _canceled.account -delete.root
  109  set root
  110  set
  111  set new.root/.disk.capacity _bellow .r6/fad.6 -open.rad /uepa
  112  set
  113  set regis
  114  set
  115  set set
  116  set
  117  set uepa.frog:confidence :rat/dat .E_42:00.01.2 _riff:ret
  118  set reply.secund /3.virus -rem -all/owl diskourt_.else.it
  119  set
  120  set s
  121  set
  122  set r
  123  set
  124  exit
  125  set tet.troxler .data-DAT:333,4 436,7 924,7 :8,9.6/4
  126  set
  127  set set
  128  set
  129  set tiplo
  130  set frog
  131  set
  132  set.x
  133  set
  134  set using.pivot
  135  set ready.mod
  136  set
  137  exit
  138  set troxler
  139  set s.7 00.01.2 :333.4 _leap .null
  140  set null
  141  set
  142  set set
  143  set
  144  set hoxler
  145  set
  146  set evi.start
  147  set
  148  set a.lpha .YA2 K
  149  set
  150  set _RET
  151  set set
  152  set
  153  set -20
  154  set
  155  set set
  156  set
  157  set trt.rev:E43,2,7:FAD.2 _else.it -truescom ,2.001573 -kill.tech
  158  set set
  159  set
  160  exit
  161  set innovation .inrect/rect .duke/morning :felschow .krakow
  162  set 193.64.122.768.2.3:eupa .s.brute /force.scanning 
  163  set -improve arms.defulte -.faulty :cash:member /person.family
  164  set set
  165  set
  166  set sledge
  167  set
  168  set bacouse:trade -auto.fill /great.whole //diction.dan -pig
  169  set
  170  set set
  171  set
  172  set throxler
  173  set frog:coups -independent.ARCH eupa.dow /light.odd :execouse
  174  set G4.F31 :s.lead .sledge.delete :del -conform
  175  set
  176  set coupe.rott /TTL:wish ...DAT.apka -reason .10 .e42 r.3.6 7
  177  set
  178  set set
  179  set
  180  set reply.secund /3.virus -rem -all/owl diskourt_.else.it
  181  set
  182  set new.root/.disk.capacity _bellow .r6/fad.6 -open.rad /uepa
  183  set
  184  set set
  185  set
  186  set troksler:ABAC .le-odd :4,21,191,2,2:23.port -DEDAC.6 .-delete
  187  set troxler
  188  set
  189  set closer
  190  set
  191  set texler.add :buroz .4.3.71-2.34.56:force -radder .maltego,auto
  192  set open
  193  set send.scan
  194  set set
  195  set
  196  set traslet.transient :eupa.method 4.21.191.45.6:bruteforce /Y6,F12
  197  set F2,e33,63,7 _space
  198  set set
  199  set
  200  set RAX dub E3,4 ,2,00 ,1
  201  set
  202  set set
  203  set
  204  exit
  205  set mork daily.event .ny.times 4,22,910,356:port.91 E.s3 F.d4 ,d3,2
  206  set f72,zu721,7,3
  207  set set
  208  set
  209  set set
  210  set
  211  set a.mork .amarok 4,3:APEC .43.21.67.52.3.6 ,4,00,01,2 :STRAP
  212  set mood.everest ,seattle:9,218,261,72,12 ,6:OMEC .A,23-4.2
  213  set set
  214  set
  215  set set
  216  set
  217  set vernition.odd -cancel :closer if.truescom let.ap.t/add
  218  set
  219  set set
  220  set
  221  set emphasys.drop _else.it:root .epa -durability :new.items /com
  222  set /compund else.react -.lios category.faulty _LITE:eupa :com.3
  223  set sat.3 elector.thor :SAT .ami ./foul.complete :build.rott
  224  set 3,56,7,2,001,0,0,0,2,E F3 C1 S04
  225  set
  226  set set
  227  set
  228  set root.vrx_ATAP.e_2,1,000 :CLOSER -step.client eve.onl:true;false
  229  set
  230  set 00,1,00000,2
  231  set
  232  set set closer
  233  set
  234  set ackles,2,31,002,0,1,00 :setup.a b,2,7,00,1 :_DROP
  235  set
  236  set UVAX:_STAGE.3.red E:clear ...DAW _SHELT.rom.2 /overdose
  237  set
  238  set avr_LET :DU.e2 -LASH.u2 _change.ip/valid -ep .distrukt _FAT
  239  set fad.sat.1 :E2 _STAMP low.freq :difficult.e,4,67,22,31,000
  240  set :avid _EMPATHOR -.live :WORLD :ESTATE .conduct.reaktor -BKM
  241  set chernobyl.setting
  242  set
  243  set chb.daw /route.rott :else.eupa _LIVING :etape .rom.2
  244  set
  245  set chil.avd /root.router:com.2_ELSE.crypt :extract -copy
  246  set 273,283,734,273,21,1,0 :_CODE.self :copy.direct RTX.manage
  247  set
  248  set cincuil.-e ,2:leps ,3,652,91 :_ALT _coil:avp /AVP_RESTART
  249  set
  250  set _AKM
  251  set
  252  set _BDOS :I.3 -else.lat.life:time _ATTEND:raul -ipos.com.3:CLOSER
  253  set B.1 :EUPA.sat.2:else.port.1 :_SHIFT:data :soul.akm /rerun.bdos
  254  set
  255  set sams._NOTE das.frezhunt:PORT.0 -2.0 :LEAP:EUPA .delete:DAUSCHZ
  256  set locate:eusa _EUSA:port.3 :leat.frog _FROULSCHZ .DAT /MIG.DATA
  257  set
  258  set _RUS.US :black.brute :IP.d /s.tape -warning.boot :else.doom
  259  set doom.if:BLACK to.get:API .route :EXTEND.extract .BLOOM _SET
  260  set
  261  set _RIOT :dus.chart :big.reat...sat.2 :COM3 portwell.redmond:E12
  262  set bios.op :REDY -doom .beat :_TROPE :INFINITY :hunday :REWELL
  263  set post.give arms.reject :plus -minus :orb.dap /run.away :HEAL
  264  set
  265  set _ago _elser.rune :dascam .online:fact,9 ,0 ,1 ,5,6 ,777 1
  266  set avo_start :elser_.dascam :runge _difact:ofm /root.n_ELSE.if
  267  set _TRUE :solid ...del /BKM.resolve _ASYNC,porto ;rott.root.m
  268  set
  269  set focusrite _elser _AV.o -fm .rm/run.boot:cypres .rd-execuete
  270  set bmw.konigwell _EST.m :23,44,E-.exe .boot /named.application
  271  set black.ice /well.name :odu -.cypres -EUPA.US_execute :datasheet
  272  set OBI.IKEA :standard shell:all.exec -route.adm2 _.WELL:ops -nute
  273  set because
  274  set
  275  set _GLOBAL .rm
  276  set
  277  set _HASH :stalingrad .loot:create.del_NUTE :level.00 :example
  278  set execute.HASH:else.stalingrad :level.brute :FORCE.mapping :EXE
  279  set HEX.ecute :LEVEL_0001 :extend.chip _IBM :synapse :LOOT
  280  set _NOMAD.audio :trotter _BUILDING.rott :item.else.if:TRUES
  281  set HEX.example :copy.root -binaric /math.cad :ARHITECT:embarcadero
  282  set embarcadero.execute //root :item.class ...boot.hex :run.exe
  283  set
  284  set G.rm -fm ,am-av ,2 :E 4.0 -hex ,4444:001:01 :2 -hate
  285  set gg.am _LUTE :VM.box /route.sat,3 ,221 ,0072 :HEX _STATE
  286  set
  287  set cougar._SEMA :eupa.stalingrad =HEX .klondike :compress
  288  set set
  289  set
  290  set if .courge :LINUX :os.end _LOOSE .NET /64x -bios _leap -countes
  291  set root.groove _lead _COUGAR .in:embarcadero -active =sarge
  292  set set
  293  set
  294  set dublin_SARGE:if.standard _LOoT.i.2:ABACUS _linux:standard
  295  set gremlin.analisys =SYS.HEX -lot.of.doom :EXP .sand=if.else
  296  set junk.mail :expander=loot.EUPA:BERLIN -.leap:democracie
  297  set vernon
  298  set
  299  set HEXEN.execute:exe -compress.xtract :medium=STALKER.add -odd/HEX
  300  set SURGE _set
  301  set
  302  set statium=HEX.clever -HONDA upcage/film ..DAT:RAW /.fad:EXE.xfile
  303  set x.file ExPAND:ROOT=SR71 ._LET:CAGE /FILM :agfa .general:exec
  304  set
  305  exit
  306  set standard.HEX _COMPUND.build=EXE -boot.sarge:ship.red :else.3
  307  set claster.rob /fex.exe -loot.FEx /bot.forever -yard.complement
  308  set blaster.SSA :FILL _FEX=boot.rox -et.m foset.av /p -m HEX:FEX
  309  set set
  310  set
  311  set get.CRYENGINE :triplex.route _EFA .IFA/extractor give.self
  312  set get.engine =FEX.hidden.object :y parameter=9,10
  313  set mile.frost _EFA=FEX hidden.cage /eupa.sat.1 _late.3 /4.0
  314  set _NUTE :noto.else.self-d.root /=FEX.cage _ip.send /id.valid
  315  set synapse:roperta :BULLFORG .detect:FROG ...DATA /auto
  316  set mechanizm.NATA elp.solu /fasa.lx /-notu.fas =LX.auto
  317  set setting.else =FAULTY .lines /duration-medical //autocage.people
  318  set id.confirm laps:PEACEMAKER -.lot /BPI ...DATA:COPY /.plus.4
  319  set c2
  320  set
  321  set COUGAR:SARGE _LARE .if-else.notu /a.2 =3.v _G.12,43,14 _NOTO
  322  set SHELL.FEX -HEXEN.direct ...pulse.radio /TV //RIOT.reality
  323  set Lamborghini./family.common -GARAGE.task /OPEN.RIOT
  324  set synapse.chip //implantation -GO:STALKER /if.set
  325  set set.incomplement :ROLL=HEX ,43,12,0,4 ,1 -NUTS:NASA
  326  set NASA.lat /imp.fex _...DATA -made.china -SINGAPURE.localization
  327  set photo.impact ...HD amarok:Shell .snap _.F.nute -open.port
  328  set
  329  set CLOSER_FEX _SURGE ///datastring .y /delete.open
  330  set
  331  set computer.bios :EMI.GG _FOREVER.spook :item.class,7 _notu:NOTO
  332  set AVM.FEX -laos :EDM.close -reboot.server -new.item _SCRIPT
  333  set jenkyns.mgr .load /ECM.2 _LEADER .alpha:delete -del.item
  334  set mood.java /rott .scr _api.app/get :URL set.d4,59 ,374 ,612 ,00
  335  set mod
  336  set _STALKER.FEX/range :crytek :BONOMO ...client :NET.4.5 :APX.clr
  337  set mercedes.loot -kill /PUBG.MAVERICKS _TRUE::false -FAULTY,4
  338  set murder.ovm -clip/film _TRUE.film /attend -DACIA.balkan :loop
  339  set _START over.loop _reverse .fact :item.NUTE /FAD.lod :reboot.2
  340  set
  341  set set
  342  set
  343  set IR.c-fantasy
  344  set open.root
  345  set set
  346  set
  347  set root.kit=SIX=HEX _METRO :cyberpunk.odd /lod.fad=FEX _client.lod
  348  set DOOM.zrg _GET:app -brutus.SIX=6 let.day am.fm=clr.rot=FEX
  349  set set
  350  set
  351  set _BRUTE=EXE.fex -eupa.sat,3:clone pvp:dashboard /laboratorie
  352  set _MX v.rouge FEX:dash /NAT.client :openport -beta:MAVERICKS
  353  set _HSZ4200 -lod :MAVERICKS -logue /DATA _GLOBE:trotter .coupe
  354  set
  355  set set
  356  set
  357  set _RUSSIAN.TRT :laos.ping /rotten.zrg -execute.extract /LIBARY
  358  set _SHIP.forever BAJKONUR:STALINGRAD/FEX.hexen -lot.big.indian
  359  set over.bus /FAD .2 /junk.notu _ELSE.budapest.if:client
  360  set BUKAREST./fex .eupa:com,9 ,1 ,00 ,0 ,e ,s ,,0
  361  set virus.ok _SELFTEST.off -boot client.data FUTURESOLDIER.DAT-RAW
  362  set is.bold -look.book /MAD,3 /2.0 -hexen.wad :asia -ping.loop
  363  set set
  364  set
  365  set trade
  366  set
  367  set cserno.sz -SASI _let.if.get:API /URAL.BAJKONUR -let.speccy
  368  set close._PROPER ,reboot -attend:car /TAXI.hour _PARKING.lot
  369  set if.else _DOOM /riot :RIOT.hexen cab.zrg //secundstate
  370  set bios.reboot /ACT,3 ,0 000,0 -4 :s .speccy
  371  set
  372  set _serpentine:wax lod.wax_LEAP
  373  set
  374  set RESTAPE_INCOIL :dubard.sat,3 _Else.If:rune :doom,7 ,2 ,10
  375  set
  376  set _SETI .apt -lounge :DOOM.WAD2:else.if:true -faulty.line :expert
  377  set _APT.run /level,9 :RUNE .drop:frame if.TV /caulty.lines
  378  set
  379  set _AFROAM
  380  set
  381  set _BACK.REACTION -ECHORDES...DATA :else.variable .r5 _SHAT.rom
  382  set
  383  set _TRACK.back
  384  set
  385  set _ABOVE.forever
  386  set
  387  set _RESTAT.forever -BIODAN.R6 :madei.it:self.classes
  388  set _MOODS .for -hate
  389  set _LAOS.R5 -restat.chernobyl 52.area
  390  set
  391  set _RESPONSE.forever
  392  set
  393  set _RESDAN.forever .tango:charlie -echo _LEAP:beta -direct.port
  394  set
  395  set TREXDER_.forever
  396  set
  397  set all.PROJECT_Foreign.one -class.auto _forever:2,10,6, 9, 1, 00,2
  398  set
  399  set _ENTER.forever :KEY.addict -forensic.detective _ACTIVE:HOLD
  400  set _SNUKE.FEX :elser .HEX /APROX.EXE .run -write.new -copy
  401  set set
  402  set
  403  set _MEREVIL .attend.hibana :EXORT.banking _LEAF.petro :UEPA.com.1
  404  set _BRUTEFORCE ...pill.zrg .lever /overbanking :SUSE .hu
  405  set CAUNTY.LORD.forever
  406  set
  407  set 1,34,7, ,2, :13 ,9 -stratocaster.a _bellow.beta /standard.acer
  408  set
  409  set set
  410  set
  411  set _progress.reboot
  412  set
  413  set _viocus.fornewer -latt .ipso =HEX.exe =FEX.alfa:start.boot
  414  set
  415  set set
  416  set
  417  set _respuTiotion :element.weapons &gt;FEX.active.action -warhead
  418  set set
  419  set
  420  set _SAM.p
  421  set
  422  set _RAX&gt;RAW=EXE&lt;HEX=FEX ,56 ,782 ,00, 0000, 9,1 0,, 1,
  423  set
  424  set set
  425  set
  426  exit
  427  set _AREA52.claymore -.forever:junk
  428  set _BRABUS.HEX -.FEX.run /.fad
  429  set
  430  set _FALLOUT .76 -rief ,4,,7,4,32,1 :1,00 -glid _ref?php :attend
  431  set _RUN :BOOT .forum :LSM .d else.if:EUPA .gold /triklat.ord -run
  432  set _REBOOT
  433  set set
  434  set
  435  set _ishio.dp,1 f,2 _leap.nute ,7:9,01 ,1 houlsch.,0 ,2
  436  set
  437  set _TRASH.eupa DOLLS.forever:FEX =do.it:HEX.hexen _let.GO:STANDARD
  438  set
  439  set set
  440  set
  441  set study_.ALIEN.2:FEX .incompund:rebell /intra.ord:HEX.DAT :ExE
  442  set
  443  set set
  444  set
  445  set build.automechanik:HEX.FEX /trotter .exec _ALIED.FORCE:trg.exe
  446  set becouse.wind :IBM.HEX =FEX .EXE loop.trotter in.force -.hello
  447  set
  448  set set
  449  set
  450  set FREELANCER.family .forever -young.HEX=FEX.A :eupa/standard
  451  set _US:force ...DATA:cage CIA.FEX/.young .else:brotherhood
  452  set set
  453  set
  454  set _HOLTER=HEX .EXE&gt;told.extract /him.fad _ELSO .war:eupa
  455  set _forever
  456  set set
  457  set
  458  set _shelter.timezones :HEX.alfa .direct :pills .ever /daclous
  459  set set
  460  set
  461  set ALIED.FUT.SOLDIER .able-forever -.eupa DISKOUNT:LATH ,4 ,000 ,1
  462  set set
  463  set
  464  set _estratos.boot =FEX
  465  set set
  466  set
  467  set _Island.ever=FEX
  468  set set
  469  set
  470  exit
  471  set _B.REDY .chill:preform -java.edu/bootserver :BOTH.exe -HEX
  472  set set
  473  set
  474  set _ikea.force .action -kampard :reject.odd /HEX=FEX :eupa.direct
  475  set set
  476  set
  477  set _snoop .virus /server.root :capacity.room //virus.desakt
  478  set s.copy -disolve art.copy /people.fees _loot.vri //system -32
  479  set mac.api /manifest _caps -lobby ---HACKERS.loop /RM.5:fewer
  480  set set
  481  set
  482  set _bious :US -bios.soul -singapur :id.item //vrd .virus.manage
  483  set 2.0 /DEDSEC manage /system ...windows.mac -dmg.extract/live
  484  set b.dos _laos /dictionery _DARKWEB.ago:hundred /execute
  485  set set
  486  set _phones.id /ip
  487  set
  488  set VRD_null.startboot -else.it:CRV.search-boot /vrd.root -extract
  489  set VRD.scan :system -build.auto /server.boot _RESTART -.DNS
  490  set set
  491  set
  492  set _genesys.compgen -VRD /root.startboot _else.linux :MAC.ip
  493  set set
  494  set
  495  set _compgen.delete /if.root:else -doorback _klient.4.5
  496  set
  497  set c:/windows/system/dedsec.hex -write.run/boot _ULS .rot .jun-k
  498  set mader.if/efx .right -bellow //gadgets .run:else.go -for.nuke
  499  set set 192.172.826.3.2 ./FEX
  500  set
  501  set kiso---forever -b2.nuke --jump2 .door:open /beta.6:six
  502  set assault--fulder.grd ---complete.b2 --reopen.door
  503  set ---frog.assault --life.2 :esc --bold.imperial ---mazeratti
  504  set set setting.def ---config .kiso :eupa.reave /MI.9 ---forever
  505  set army.drop ---black.operation :phantom ---sight.mi.9 --ever
  506  set set drop.evening ---morning -am.fm --massive.6 /--server.virus
  507  set black--operation ---helicopters.marshalls .well ---process
  508  set set
  509  set
  510  set set.tes
  511  set
  512  set ---self.people_once
  513  set
  514  set removal.kit --forever- _leash.VRD:eupa/north.korea sat.10
  515  set setting --else.remove ---default.virus --boot -login
  516  set set
  517  set
  518  set ----bot.boot -vrd
  519  set
  520  set /rapid.travell ---forever.young --rapid ----ruber.force--black
  521  set set
  522  set
  523  set :--viruge.ord --freecommon .task /rite.default --forever .CC
  524  set application.jenkyns /java --young _else.synthesis ---android
  525  set :eupa.com.10 sat.8 --ever -lot /fees .action -emphasys .error
  526  set set common.diskplace SSD.forge:HDD com.self --AMD.INTEL --jag
  527  set jager--top.pop --leaver .counted.monkey ---forever
  528  set
  529  set fat.e -commands ---forever.virus /viruge.if:alpha ...data
  530  set set ---commands slave.force /villo .data :shape.inform
  531  set form.aif write.commands mac=windows =HEXE
  532  set set command.else if.do:complete
  533  set
  534  set t--rotter -dam --forever -bpi.scitec ----bash.open/DNS:deploy
  535  set frog--forground.black --white ----for.ever:bash --id.complete
  536  set set
  537  set
  538  set total---care.obama _care.set /riff lady.GG ---supercharger --id
  539  set idm-forever -lash---for.ever -cash---post --run:GO
  540  set set
  541  set
  542  set programming---excess --endless -os
  543  set set
  544  set
  545  set post.---script --memento.morning EVE -lash---direct.local
  546  set perspective.autodesk ---forever.complete all.method ---hexe
  547  set set config.delete ---punkjunkies.chip --chip -remote
  548  set bell-----white
  549  set
  550  set :hexen ---snoopy.retry --dash.all /sad.3 _exec--fulder/root.ord
  551  set set
  552  set
  553  exit rotte
  554  set ping---everlost.error
  555  set set
  556  set
  557  exit config
  558  set evaser.metasploit --blue.whole
  559  set set
  560  set
  561  set _ferguSON.del ---forever -whole ---blue -red ----green _eupa:id 
  562  set set
  563  set
  564  set .root--def syrius.army ---log.default:router --dx7.remember:id
  565  set set
  566  set
  567  set .whole --blue.log --read
  568  set set
  569  set
  570  set virtual.maschine --mk2.es1 ---red
  571  set set
  572  set
  573  set forever.end ---ready.ok
  574  set set
  575  set
  576  set fulder.ind ---for.ever
  577  set set
  578  set
  579  set :ivp---round =HEX.item send.postedbox ---trivial.engine --full
  580  set set
  581  set
  582  exit capability
  583  set ext.2 ---write.all
  584  set
  585  exit capability.manager
  586  set borg---.ever forever  --do.stat _relief
  587  set set start.whole.sad _deploy /.rotte
  588  set
  589  set else--borg.boot ---forever.lock ---green
  590  set set
  591  set
  592  set forever--alied -forge ---dashboard.common
  593  set tasking--give --alien:dedcode --bot.boot
  594  set kamikaze---forever.bot
  595  set set
  596  set
  597  set alied--for.nuke ---white --noize:2 -bot.boot
  598  set kamikaze.cat ---forever
  599  set set
  600  set
  601  set -meth---life -hash --try:common /bad.3
  602  set bad.3 ---relief --for.ever ---last -GO
  603  set set event---reployment --forgive.last -ever
  604  set bash---hashtag.forever -vrd.common --tasking
  605  set set
  606  set delete.virus /-relief -cash ---made -laos 
  607  set set
  608  set
  609  exit told mechanizm
  610  set aviation.complete ---forever.terror -if.load ---odd
  611  set set
  612  set
  613  exit port.close--forever
  614  set extract.config--terror.forever -not.possible -vrd.run
  615  set set
  616  set
  617  exit port.well--forever -junk---dallas
  618  set door.com.3:server.virus --lead .detect :off -leader /HEXEN.FEX
  619  set set
  620  set
  621  exit lobby
  622  set EUPA.server virus--com.3:portclose --have.forever ---just:GO
  623  set set
  624  set
  625  exit lobby
  626  set vsop.cardlist ---forever -junk.hape ---made.paris  -mood
  627  set set
  628  set
  629  set --improve -else---standard --enemie -die -frog --delete -force
  630  set set
  631  set
  632  exit to:GO
  633  set new.properate --forever /-dash.rock _mull.size 82.91.1.0.00.2
  634  set network.progres -discovery.take:build /.item ---laos.rule
  635  set set
  636  set
  637  set bg52--forever .GO _also.military ---DEFENSE.alto :manager.ivp
  638  set big.beat :UKRAINE ---GO -for.ever 3,2,00,000,0,1,,2
  639  set MIG---4200.local -selftest ---before.advanced.warfare
  640  set kid.g36 ---glock.redy ready.ok -access.vrd--forever---white
  641  set set
  642  set
  643  set amorph.borq---for.ever -jud /jad.1 _also.give -gateway:20.ping
  644  set sleet.jad /.-forgive ,00,0,2,1,0000,1,3 , 3 ,91
  645  set IBM.dell -.execute.forever --ping.token ---virus.serum --boot
  646  set set
  647  set
  648  exit ---jav.mem -boot .ivm /reaktor --rock.ace
  649  set give.app -delete ---forever es1.mk2 --boot.ini -bot /mk2
  650  set set
  651  set
  652  set ovd.mem---for.duke --newer -life _agent:guns --stappy -ranked
  653  set id.rank /wwf --dursch -magnet _hilfe ---boot -ai -mi /4200
  654  set local.es send.async --forever.lock -imageline /vifon.rad radius
  655  set item.radius /silver -light ---forever -nat _klient.rad /-FAD.1
  656  set set
  657  set
  658  set petro-.forever---white -ai.mi --boot _synapse.system /send.log
  659  set set
  660  set
  661  set petro--blue
  662  set
  663  set fullsale/.-lambert ---forever.cast _leap.HEXE -add.ord
  664  set set
  665  set auto.logger _didact.os/---white .educast --hexe.odd -fexen
  666  set set
  667  set
  668  set revolution.--white
  669  set set
  670  set
  671  set .---white :shark /.revolution.escape --fear -online ---board
  672  set ingread.item ---forever.hexen fex EN.log -activate.autolawyer
  673  set dell.sec ---dedsec item:CT-os ---shark.blue -noize
  674  set set
  675  set
  676  set apex---purple.blue _shark.black ---water -ord.odd/boot -ref
  677  set set
  678  set
  679  set imperial---whole.purple --red -shack---forever
  680  set set
  681  set
  682  set APEX--shurk stark.elso---forever.fullsale --STD.else--noize-es
  683  set set
  684  set
  685  set a-bee--for ---white-blue --noize.brown--es1 -young--indigo.cage
  686  set abelec--apex -light ---fullsale --aboth -rurkes --explotation
  687  set set
  688  set
  689  set es-logue---shacky -dawn--royale ---ups --detected-ruler -visual
  690  set bronx.-log ---white -.sat.1 --solidstate ---dreamweaver -sony
  691  set set
  692  set
  693  set klondike--shark -white
  694  set set
  695  set
  696  exit eupa.sat
  697  set imageline--whole.red ---blue -green ---blackwater
  698  set set
  699  set
  700  set sat.1-all beliefe-item,3 ...secund --whale -judge ---id
  701  set set
  702  set
  703  set just--token-0.1..00...0.3..7..2..9.1.00 ---whore.engine mdx5
  704  set engine--phasegenerator---both --sick --ever --forever
  705  set set
  706  set
  707  set just.slave -test
  708  set
  709  set aborg--frog -whittin ---klinde --massarce -white.noise ---korg
  710  set set
  711  set
  712  set stalker--vhs --tremor.-sat,1,1,1 :3.fad ---for .nuke _asset.one
  713  set set aviator.---village --people.dark -shade.modern ---gun
  714  set model.gun --pin -kingpin ---vrg -sat_.asset --once---white
  715  set
  716  set brutus--commando -rite ---forensic -CHN.16 --dead.code -surgeon
  717  set set surge--ping -rebellion ---babylon -delete.form -tag
  718  set fn.herstal ---wittin -dark ---time ---low -capacity ----ded
  719  set set
  720  set
  721  set c++.ibm-asus-razer --passed.acer -forge gta.online-petro
  722  set c+.pascal --quit.operation ---green.bend -alpha.beta ---vied
  723  set relief.c++ _sat.3-purpose.delta HR-.herstal---hexen
  724  set set meth.lambert --delta ---god -hr --reference -mi5 -mi -ai
  725  set
  726  set log.drone :FEW.platan ,00,1,0,21,01 ---bush --governor.local
  727  set
  728  set SURGEON.--serum.synth ---mavericks.grd -white ----synthesys
  729  set set
  730  set
  731  set forum.---level.10 --white .esac---forever --nacht ---lotus -id
  732  set set
  733  set
  734  set sub.ana -mariner ...data ,e2 --white ---operator -propegate -id
  735  set set
  736  set
  737  set purple.white --forever -serum.syrius-item --frog.else _if.STD
  738  set bush --brown -leader.items ---eupa _amber.leave -white.noise
  739  set set drop.frame in.mavericks ---white -brown ---wisky -jump.er
  740  set
  741  set tempy./dedsec --free.zed -run.baby ---white -shark
  742  set set
  743  set
  744  set lock ---blue
  745  set
  746  set folder.x---whitten -pro-pet---red :dedsec.live -----null
  747  set set
  748  set
  749  exit -----voil.entrance
  750  set execute---farmcar.evo---red.y _drop.items --autotrader ---cab
  751  set set extract.job ---jobe -white -----standard --KGB.item -blue
  752  set
  753  set ---flotta.rim -execute ---trotter -com  ---white.nso -----cage
  754  set rim---flotta jobs--drop --exellence ---bmw.motors ---lawyer
  755  set set goal:GO --ride.rite ---brown-run --close-forever -serum
  756  set
  757  set ---yakuza-san--son -etape --surge ---whele.rim ---flotta --bot
  758  set set
  759  set
  760  set ----umbrella -TEK---black -commando.police ---white-noize
  761  set
  762  set exit.proof _excellence.rov ---proper
  763  set
  764  exit set.code
  765  set houst.triplex --sade-radial--execute zero.zad --else.white
  766  set black.else -white off.sequnce ---ready.wave -operation.count
  767  set
  768  exit puffer
  769  set comframe-found ---triplexer.ade-hate --black.commando
  770  set set drumcode--hyperspace ---found.leash ---tap.car-white
  771  set
  772  exit buffer
  773  set anomi---push.jump --jumper mobile.cat --export.mi9 --hashtag
  774  set set a.vorm---execute mbl.rat ---run.protokol --blue ---whole
  775  set
  776  set drg.rom --platan.execure ---dols -dir /.fad-rip
  777  set set
  778  set
  779  set eupa.wade ---longhorn-distance --lock.wad--else.run ---ct
  780  set
  781  set let.forever---whitehorn --b.gen -trops ---live
  782  set set
  783  set
  784  set doors.eve ---complete.earth -vhol---ukrin:sad:HEXE :GO---faith
  785  set set
  786  set
  787  set nazi-live -strapas ---hell.overbit --can.owl ---ahead-forever
  788  set set
  789  set logging.set:send ---000
  790  set
  791  set set
  792  set
  793  set logfile.index--bruteforce
  794  set aparate.log--inforce
  795  set beta2.white
  796  set set
  797  set
  798  set hellraiser
  799  set ukr.cherno
  800  set setup.86
  801  set
  802  set set
  803  set
  804  set item...physe --rot.ten..data _else.if:complete /data.fad ---rom
  805  set mobile.cat---physe.ten-rot ...daw.rot _else.wad:enter.direct
  806  set set
  807  set
  808  set set.reday -faraday.ok _item .txt---cat.mobile-forever
  809  set attend.physe --day ---longitem -hour /fad.000 ---white
  810  set
  811  set set
  812  set
  813  exit zet zed
  814  set solar.game-execute---borderland :item/game.snr _coolthings
  815  set set -.sonar:elso.if=HEXEN.rotter ...data.raw _execute.extract
  816  set bion.glade :cat.mobile standard.assign ---for.ever ----olive
  817  set set
  818  set
  819  set set
  820  set
  821  exit GO:solar
  822  set aborted.-fills /---forever --white -cage-open---full.defrag
  823  set set debug -file -write/windows.os _MAC:address ---complete
  824  set
  825  set etran.dioxin ---framecut-werk---schlassbaden ---class.7 -white
  826  set set
  827  set
  828  set zed---zet.a -b-ta /7,01 ,301 ---scape.mod -excalibur ---shade
  829  set lock
  830  set
  831  exit landrover
  832  set shark.armed---whittin --force.brute-loving --dark.greenbrute
  833  set set
  834  set
  835  set off.cur ---force.greenbrute --livid.liquid ---expas.odr -run
  836  set
  837  set new.order--moonrocks -fit--troopforce-cur_ykz ---brute-frz
  838  set set borderland.rocks ---forever.dawn setting:new.dawn--piece
  839  set koppenhagen.tremor---self:it.else -rock ---moonrocks
  840  set set
  841  set
  842  set set
  843  set
  844  set def.caf ---enter.locked-brute ---extasy.data--loock --data-raw
  845  set set
  846  set
  847  set config-yep
  848  set set
  849  set
  850  set moon---rocks -eve--forge-loock
  851  set
  852  set jra.ira---tastics-plastics -ibm--rounder-cab--pop-duty.call
  853  set future.soldier---taktiks ---forever.nuke---green.matrix -call
  854  set set
  855  set
  856  set loock
  857  set
  858  exit start.hobit
  859  set caf.duty---all.infinity ----tom.clancy-wore:borq --extend.puf
  860  set set puffer---forever.buffering -tom--rat:fad ---boot
  861  set
  862  set run&gt;dedcode
  863  set set
  864  set
  865  set ded.sec---delete.admin --confuse.user---forever-brute ----ping
  866  set
  867  set set
  868  set
  869  set silver.matrix ---extend--rott -ylo.debug
  870  set
  871  exit cur.start
  872  set medium.clr---forever -plus.minus ---red.toppy ...topic.data
  873  set set collin.farad id.name charter.ops --fast.during:methode
  874  set set
  875  set
  876  set set
  877  set a
  878  set b
  879  set c
  880  set set
  881  set
  882  set time.matrix---cur - -b -c ---forever.07,120,34,10....0000
  883  set izotope.irix -setup.grounds ---proving-else -set.cur
  884  set set
  885  set
  886  set borq.timematrix zero,0---forever.cur _leap ...data.raw:shift
  887  set set loock.lock:asset,0 --white -cur---redfact -faction-manufact
  888  set set beyond
  889  set
  890  set set a
  891  set set b
  892  set set c
  893  set
  894  set cur.DATA--blaster.brute ---force.ever --mood.eve ---redfaction
  895  set DATA.cur is.RAW---SHARK.odd ---synthesis-cyborg---future.brute
  896  set set brute.efx---WHALE ---forever.last --headline.future-pack
  897  set
  898  set set a
  899  set set b
  900  set set c
  901  set set
  902  set
  903  set debug---cef
  904  set
  905  exit re-bot
  906  set fidger-arld ---white.start-blue ---monday.dat
  907  set
  908  set respawn.remedy---forever.young --blue.whale ---extract.client
  909  set set -up review.login---droppin -field -look.body-thight--elf
  910  set
  911  set collin
  912  set
  913  set set
  914  set
  915  set .cur---iwi ...SHARK..white ---manufacturer-local:id ---bethesda
  916  set set
  917  set
  918  exit curv
  919  set white---whale -operation---sale-wore -alien--ware ---discount
  920  set set
  921  set
  922  exit deal
  923  set vurneal.city ---clash -worg
  924  set set
  925  set
  926  set set angliour.-space.sense ---neo.robotics --gardenkeep...data
  927  set
  928  set set complex---compress.-execute -.-live.act--razer ---compaq
  929  set
  930  set set SAEP..sett -ernough--shack-war .-low.thing ---eclipse
  931  set
  932  set verificator.decline ---root.bash_powershell -ecognite
  933  set bulsch.tm ---vector -apranet --robotic.mecha
  934  set set underway.router --propellerheads--shark.white
  935  set
  936  set argent.power-up --shat-white ----falls.peak -resume
  937  set set
  938  set
  939  exit roperta
  940  set befulll--shatness -whole ----attender.exact _drop.flat
  941  set set
  942  set
  943  set amorph.borq---for.ever -jud /jad.1 _also.give -gateway:20.ping
  944  set big.beat :UKRAINE ---GO -for.ever 3,2,00,000,0,1,,2
  945  cat /home/username/bash_history
  946  cat /home/root/bash_history
  947  history
  948  set topic/all -top .reveleence
  949  set
  950  top
  951  set aproxy-.metal /logue :top
  952  top
  953  set /else top
  954  set
  955  top
  956  ccode
  957  code
  958  far
  959  liep
  960  leap
  961  note
  962  copy
  963  command
  964  topicű
  965  1  set aviation. 191.2.34.158.1
  966  top
  967  set root/desktop .and -etd --run
  968  top
  969  top auto
  970  top -d
  971  top
  972  top -w
  973  reset
  974  set hvm
  975  top
  976  set softlayer.topic/pound.drd /isom.fad -dear.dump /.rocket
  977  set billing.data /airsoft.air --shud.whole _lead:cygwin /power -C
  978  set visual.basic
  979  top
  980  set arguemtal:chivok :preage --countur -destination --uvn /fad
  981  top
  982  set reply :ROG-GLWV drag.cygwin .set /top -else.route
  983  top
  984  set bistroy._EXEC /fex.execute -local.ip
  985  set
  986  clear
  987  set coverage.topic/omen -reach -os2 _LINE :drop.frame ----x
  988  top
  989  set aproxy./metal -isd .sm /such-.vmz --top.topy
  990  set
  991  clear
  992  set avm.destruction.leap /task:xorg :XORG
  993  set
  994  clear
  995  set top2/api .get -.git /pubg.focus
  996  top
  997  set pixocom._let begin.end /falls :direct
  998  set
  999  clear
 1000  set container.app /muskled ..damp /trojschig :vacum
 1001  set
 1002  reset
 1003  set fillow._argurentum /fixed.bug
 1004  set
 1005  clear
 1006  set trivial..trig/goppeers .tycoon :relevent -EvE
 1007  set
 1008  reset
 1009  set boot.stappen/iloy .convule :ip.d -derosch /cda
 1010  set
 1011  set vrd {extract}
 1012  set
 1013  set {execute} trigger.rated.database
 1014  set
 1015  set {zrg.executed--rule}:binaries :norton.fsdos /dos.am2 .fm2 -fm4
 1016  set
 1017  set rule.closer
 1018  set
 1019  reset
 1020  set billar told /hat.him -self .begun _else.top2
 1021  top
 1022  set rope.-tops /engine -poproof :door .common
 1023  set
 1024  clear
 1025  set press.tap /rorr ...datu _else.if:faction:automate
 1026  set
 1027  exit
 1028  set backdoor:give.app -lief.direct /appegine ...data:code
 1029  set
 1030  reset
 1031  set &apos;c1
 1032  set often.vorg -restart /all.device :conform.ada
 1033  c&apos;
 1034  set
 1035  clear
 1036  exit
 1037  set topofthepop.forensics/dataminer -miner.roof /parasequence
 1038  set
 1039  top
 1040  history
 1041  set
 1042  set hexen--valid -open--vm.box
 1043  set arch
 1044  set
 1045  set s.tape-s --ss
 1046  set
 1047  set cygwin./repo.ext44 -.copy.desktop :vb -esb --program.manager
 1048  set
 1049  set -./otus.op
 1050  set
 1051  set metha.set -.obs.log
 1052  set
 1053  set }brute
 1054  set
 1055  set }config{execute}&lt;delete /storage.format _else.world
 1056  set
 1057  set  &lt;exclecuder -.brute.if;else
 1058  set
 1059  history
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;0&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=history
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.?(t)bz?(2)&quot; [dragon]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e)ps|pdf)&quot; [gpdf]=&quot;!*.[pf]df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e)ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e)ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.?(t)bz?(2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp?(e)g?(2)|j2[ck]|jp[2f]|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|?(e)ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t]m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)?(.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [pbunzip2]=&quot;!*.?(t)bz?(2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|?(d)patch)?(.@([gx]z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/}&quot; compfile;
    [[ -n $cmd ]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref () 
{ 
    local exclude i j line ref;
    if [[ -n $1 ]]; then
        exclude=&quot;${1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
    printf -v &quot;$3&quot; %s &quot;$COMP_CWORD&quot;;
    if [[ -n $exclude ]]; then
        line=$COMP_LINE;
        for ((i=0, j=0; i &lt; ${#COMP_WORDS[@]}; i++, j++))
        do
            while [[ $i -gt 0 &amp;&amp; ${COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]]* ]] &amp;&amp; (( j &gt;= 2 )) &amp;&amp; ((j--));
                ref=&quot;$2[$j]&quot;;
                printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
                [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -g -- &quot;$1&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -Gn 2&gt;/dev/null || groups 2&gt;/dev/null )&quot; -- &quot;$1&quot; ));
    fi
}
_allowed_users () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -u -- &quot;${1:-$cur}&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -un 2&gt;/dev/null || whoami 2&gt;/dev/null )&quot; -- &quot;${1:-$cur}&quot; ));
    fi
}
_available_interfaces () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY=($( {
        if [[ ${1:-} == -w ]]; then
            iwconfig
        elif [[ ${1:-} == -a ]]; then
            ifconfig || ip link show up
        else
            ifconfig -a || ip link show
        fi
    } 2&gt;/dev/null | awk         &apos;/^[^ \t]/ { if ($1 ~ /^[0-9]+:/) { print $2 } else { print $1 } }&apos; ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]/%[[:punct:]]/}&apos; -- &quot;$cur&quot; ))
}
_cd () 
{ 
    local cur prev words cword;
    _init_completion || return;
    local IFS=&apos;
&apos; i j k;
    compopt -o filenames;
    if [[ -z &quot;${CDPATH:-}&quot; || &quot;$cur&quot; == ?(.)?(.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/&quot; ]]; then
            COMPREPLY[0]=&quot;${i}/&quot;;
        fi;
    fi;
    return
}
_cd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?([amrs])cd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_command () 
{ 
    local offset i;
    offset=1;
    for ((i=1; i &lt;= COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            offset=$i;
            break;
        fi;
    done;
    _command_offset $offset
}
_command_offset () 
{ 
    local word_offset=$1 i j;
    for ((i=0; i &lt; $word_offset; i++ ))
    do
        for ((j=0; j &lt;= ${#COMP_LINE}; j++ ))
        do
            [[ &quot;$COMP_LINE&quot; == &quot;${COMP_WORDS[i]}&quot;* ]] &amp;&amp; break;
            COMP_LINE=${COMP_LINE:1};
            ((COMP_POINT--));
        done;
        COMP_LINE=${COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT-=${#COMP_WORDS[i]}));
    done;
    for ((i=0; i &lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i]=${COMP_WORDS[i+$word_offset]};
    done;
    for ((i; i &lt;= COMP_CWORD; i++ ))
    do
        unset &apos;COMP_WORDS[i]&apos;;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY=();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD -eq 0 ]]; then
        local IFS=&apos;
&apos;;
        compopt -o filenames;
        COMPREPLY=($( compgen -d -c -- &quot;$cur&quot; ));
    else
        local cmd=${COMP_WORDS[0]} compcmd=${COMP_WORDS[0]};
        local cspec=$( complete -p $cmd 2&gt;/dev/null );
        if [[ ! -n $cspec &amp;&amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec ]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec ]]; then
            compcmd=${cmd##*/};
            _completion_loader $compcmd;
            cspec=$( complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec ]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt=${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec=${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set {ren.instead history
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;0&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=history
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.?(t)bz?(2)&quot; [dragon]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e)ps|pdf)&quot; [gpdf]=&quot;!*.[pf]df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e)ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e)ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.?(t)bz?(2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp?(e)g?(2)|j2[ck]|jp[2f]|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|?(e)ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t]m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)?(.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [pbunzip2]=&quot;!*.?(t)bz?(2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|?(d)patch)?(.@([gx]z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/}&quot; compfile;
    [[ -n $cmd ]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref () 
{ 
    local exclude i j line ref;
    if [[ -n $1 ]]; then
        exclude=&quot;${1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
    printf -v &quot;$3&quot; %s &quot;$COMP_CWORD&quot;;
    if [[ -n $exclude ]]; then
        line=$COMP_LINE;
        for ((i=0, j=0; i &lt; ${#COMP_WORDS[@]}; i++, j++))
        do
            while [[ $i -gt 0 &amp;&amp; ${COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]]* ]] &amp;&amp; (( j &gt;= 2 )) &amp;&amp; ((j--));
                ref=&quot;$2[$j]&quot;;
                printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
                [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -g -- &quot;$1&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -Gn 2&gt;/dev/null || groups 2&gt;/dev/null )&quot; -- &quot;$1&quot; ));
    fi
}
_allowed_users () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -u -- &quot;${1:-$cur}&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -un 2&gt;/dev/null || whoami 2&gt;/dev/null )&quot; -- &quot;${1:-$cur}&quot; ));
    fi
}
_available_interfaces () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY=($( {
        if [[ ${1:-} == -w ]]; then
            iwconfig
        elif [[ ${1:-} == -a ]]; then
            ifconfig || ip link show up
        else
            ifconfig -a || ip link show
        fi
    } 2&gt;/dev/null | awk         &apos;/^[^ \t]/ { if ($1 ~ /^[0-9]+:/) { print $2 } else { print $1 } }&apos; ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]/%[[:punct:]]/}&apos; -- &quot;$cur&quot; ))
}
_cd () 
{ 
    local cur prev words cword;
    _init_completion || return;
    local IFS=&apos;
&apos; i j k;
    compopt -o filenames;
    if [[ -z &quot;${CDPATH:-}&quot; || &quot;$cur&quot; == ?(.)?(.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/&quot; ]]; then
            COMPREPLY[0]=&quot;${i}/&quot;;
        fi;
    fi;
    return
}
_cd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?([amrs])cd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_command () 
{ 
    local offset i;
    offset=1;
    for ((i=1; i &lt;= COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            offset=$i;
            break;
        fi;
    done;
    _command_offset $offset
}
_command_offset () 
{ 
    local word_offset=$1 i j;
    for ((i=0; i &lt; $word_offset; i++ ))
    do
        for ((j=0; j &lt;= ${#COMP_LINE}; j++ ))
        do
            [[ &quot;$COMP_LINE&quot; == &quot;${COMP_WORDS[i]}&quot;* ]] &amp;&amp; break;
            COMP_LINE=${COMP_LINE:1};
            ((COMP_POINT--));
        done;
        COMP_LINE=${COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT-=${#COMP_WORDS[i]}));
    done;
    for ((i=0; i &lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i]=${COMP_WORDS[i+$word_offset]};
    done;
    for ((i; i &lt;= COMP_CWORD; i++ ))
    do
        unset &apos;COMP_WORDS[i]&apos;;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY=();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD -eq 0 ]]; then
        local IFS=&apos;
&apos;;
        compopt -o filenames;
        COMPREPLY=($( compgen -d -c -- &quot;$cur&quot; ));
    else
        local cmd=${COMP_WORDS[0]} compcmd=${COMP_WORDS[0]};
        local cspec=$( complete -p $cmd 2&gt;/dev/null );
        if [[ ! -n $cspec &amp;&amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec ]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec ]]; then
            compcmd=${cmd##*/};
            _completion_loader $compcmd;
            cspec=$( complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec ]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt=${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec=${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># take two.com:5 rest;big _rom/ram
bash: take: parancs nem található
bash: big: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font>#      efc.x reach.void :ssm.rage
bash: efc.x: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font>#          graw.mission g-doom
bash: graw.mission: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># gg.aspect /fellow
bash: gg.aspect: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># atec.willam /descont in.proof
bash: atec.willam: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font>#      apet.rillow mat.chl/thru:false
bash: apet.rillow: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font>#      app.let GO:trash2.gov
bash: app.let: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font>#   make.disolve
bash: make.disolve: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># write change.go
write: change.go is not logged in
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># eprox.applet superjunk.made
bash: eprox.applet: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># solve.trude -ipso -grade /grande
bash: solve.trude: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># if.make such.eleven
bash: if.make: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># bolden.extact trash:ozone -nat
bash: bolden.extact: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># work.much sheet.move gg-framework
bash: work.much: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># build.gen made.iraq /sonda.vorg
bash: build.gen: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set borq.clure -mind.evorg
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># sat a-gg /tallit go:reform
bash: sat: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># astyc.revenge -hope.jail /shade
bash: astyc.revenge: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># mood.gg -texture.commando -go
bash: mood.gg: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># cs:gg trotter give.standard
bash: cs:gg: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># maximum.reload ;thru-frame
bash: maximum.reload: parancs nem található
bash: thru-frame: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># woiden.aif -go.rec go.offset
bash: woiden.aif: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># make.plod -conjuecvence:mylord
bash: make.plod: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># hade.porter ;junk.file -a.script
bash: hade.porter: parancs nem található
bash: junk.file: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># hash/tread :punk -cyber.gg
bash: hash/tread: Nincs ilyen fájl vagy könyvtár
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># mash:go alive.allieragus /podovan
bash: mash:go: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># asture.give is.set null/date
bash: asture.give: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># mask relief.auto -proper
bash: mask: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># guide-affect -ebola /shrink.dt
bash: guide-affect: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># aprox.if ross.eu -rus.made
bash: aprox.if: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># echo.proving :go.ground -gg
bash: echo.proving: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># let.made if.eve:online -zrg.mate
bash: let.made: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># endless.os -few.mac -pc/gg/cal -cat
bash: endless.os: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># aviro.model /category.chl
bash: aviro.model: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># lash.evening -evo coffe-task.mod
bash: lash.evening: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># emperiour.dtm /evo .automatic/replay
bash: emperiour.dtm: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># shadt.hank /rg.paste /frame.borders
bash: shadt.hank: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># shrink.duplex made.fortyfive-seven
bash: shrink.duplex: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># ultiplex...ny data:comit /revenge
bash: ultiplex...ny: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># u.plash corrigated.client -go.gg
bash: u.plash: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># made.under /category.dat relief...cat
bash: made.under: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># hub.shrink -cat/delay :umax/tellov
bash: hub.shrink: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># racionerie.fo /run.center -upload
bash: racionerie.fo: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># date.breader /chill -homez /grasth
bash: date.breader: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># freash.takker ontario.glavs -telaviv
bash: freash.takker: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># tel.call /direct some.if.soul
bash: tel.call: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># miramar.press /grid.ruska _all
bash: miramar.press: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># rusky.hope /chater -give.pool --fad
bash: rusky.hope: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># assault.berlin /riga.data :del
bash: assault.berlin: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># abroad -gg/chill vengeance.raw -offset
bash: abroad: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># xbox.hat-red /caulty /push.plus
bash: xbox.hat-red: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># ranger.wad -exchause.wait /doom
bash: ranger.wad: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># ring.belt /vietnam -gg.soul
bash: ring.belt: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># peru.wad /range.over .del-go
bash: peru.wad: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># tap.bpm -tempo.van /ACE.script
bash: tap.bpm: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># write.max collise.min set.if
bash: write.max: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># coil.write /capsule.mts -gg;go/desk
bash: coil.write: parancs nem található
bash: go/desk: Nincs ilyen fájl vagy könyvtár
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># rade.comax /prash :tool.tab -open
bash: rade.comax: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># wang.traplet :if-gg/defense
bash: wang.traplet: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># growash./superior :max.offset
bash: growash./superior: Nincs ilyen fájl vagy könyvtár
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># bagett.open -desk/deploy -right
bash: bagett.open: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># massive.fm /caolistic.frame ;true
bash: massive.fm: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># comtrues;load.close -begun.left
bash: comtrues: parancs nem található
bash: load.close: parancs nem található
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=([0]=&quot;0&quot;)
BASH_ARGV=()
BASH_CMDS=()
BASH_COMPLETION_VERSINFO=([0]=&quot;2&quot; [1]=&quot;8&quot;)
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]=&quot;5&quot; [1]=&quot;0&quot; [2]=&quot;3&quot; [3]=&quot;1&quot; [4]=&quot;release&quot; [5]=&quot;i686-pc-linux-gnu&quot;)
BASH_VERSION=&apos;5.0.3(1)-release&apos;
COLORTERM=truecolor
COLUMNS=80
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
DESKTOP_SESSION=gnome
DIRSTACK=()
DISPLAY=:1
EUID=0
GDMSESSION=gnome
GDM_LANG=hu_HU.UTF-8
GJS_DEBUG_OUTPUT=stderr
GJS_DEBUG_TOPICS=&apos;JS ERROR;JS LOG&apos;
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
GNOME_TERMINAL_SCREEN=/org/gnome/Terminal/screen/bcc48bca_9557_4b2a_a05d_ce45eb1fc0eb
GNOME_TERMINAL_SERVICE=:1.63
GPG_AGENT_INFO=/run/user/0/gnupg/S.gpg-agent:0:1
GROUPS=()
GTK_MODULES=gail:atk-bridge
HISTCONTROL=ignoreboth
HISTFILE=/root/.bash_history
HISTFILESIZE=2000
HISTSIZE=1000
HOME=/root
HOSTNAME=root
HOSTTYPE=i686
IFS=$&apos; \t\n&apos;
LANG=hu_HU.UTF-8
LINES=51
LOGNAME=root
LS_COLORS=&apos;rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:&apos;
MACHTYPE=i686-pc-linux-gnu
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
PIPESTATUS=([0]=&quot;127&quot;)
PPID=1543
PS1=&apos;\[\e]0;\u@\h: \w\a\]${debian_chroot:+($debian_chroot)}\[\033[01;31m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ &apos;
PS2=&apos;&gt; &apos;
PS4=&apos;+ &apos;
PWD=/root
QT_ACCESSIBILITY=1
SESSION_MANAGER=local/root:@/tmp/.ICE-unix/939,unix/root:/tmp/.ICE-unix/939
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_AGENT_PID=991
SSH_AUTH_SOCK=/run/user/0/keyring/ssh
TERM=xterm-256color
UID=0
USER=root
USERNAME=root
VTE_VERSION=5402
WINDOWPATH=2
XAUTHORITY=/run/user/0/gdm/Xauthority
XDG_CURRENT_DESKTOP=GNOME
XDG_DATA_DIRS=/usr/share/gnome:/usr/local/share/:/usr/share/
XDG_MENU_PREFIX=gnome-
XDG_RUNTIME_DIR=/run/user/0
XDG_SEAT=seat0
XDG_SESSION_CLASS=user
XDG_SESSION_DESKTOP=gnome
XDG_SESSION_ID=2
XDG_SESSION_TYPE=x11
XDG_VTNR=2
_=-begun.left
__git_printf_supports_v=yes
_backup_glob=&apos;@(#*#|*@(~|.@(bak|orig|rej|swp|dpkg*|rpm@(orig|new|save))))&apos;
_xspecs=([lokalize]=&quot;!*.po&quot; [acroread]=&quot;!*.[pf]df&quot; [lbzcat]=&quot;!*.?(t)bz?(2)&quot; [mpg321]=&quot;!*.mp3&quot; [bzcat]=&quot;!*.?(t)bz?(2)&quot; [oocalc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [tex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [unlzma]=&quot;!*.@(tlz|lzma)&quot; [sxemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [aviplay]=&quot;!*.@(avi|asf|wmv)&quot; [lbunzip2]=&quot;!*.?(t)bz?(2)&quot; [dragon]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [freeamp]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [rgvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ooimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [gqmpeg]=&quot;!*.@(mp3|og[ag]|pls|m3u)&quot; [texi2html]=&quot;!*.texi*&quot; [hbpp]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [lowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [qiv]=&quot;!*.@(gif|jp?(e)g|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|svg)&quot; [xanim]=&quot;!*.@(mpg|mpeg|avi|mov|qt)&quot; [ps2pdfwr]=&quot;!*.@(?(e)ps|pdf)&quot; [harbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [jadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [dvitype]=&quot;!*.dvi&quot; [lobase]=&quot;!*.odb&quot; [rpm2cpio]=&quot;!*.[rs]pm&quot; [xine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [lualatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [localc]=&quot;!*.@(sxc|stc|xls?([bmx])|xlw|xlt?([mx])|[ct]sv|?(f)ods|ots)&quot; [hbrun]=&quot;!*.[Hh][Rr][Bb]&quot; [amaya]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [gv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [unpigz]=&quot;!*.@(Z|[gGdz]z|t[ag]z)&quot; [mozilla]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [epdfview]=&quot;!*.pdf&quot; [dvips]=&quot;!*.dvi&quot; [pdfunite]=&quot;!*.pdf&quot; [ps2pdf14]=&quot;!*.@(?(e)ps|pdf)&quot; [kid3]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [vi]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ps2pdf]=&quot;!*.@(?(e)ps|pdf)&quot; [gpdf]=&quot;!*.[pf]df&quot; [lilypond]=&quot;!*.ly&quot; [texi2dvi]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [modplug123]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [znew]=&quot;*.Z&quot; [ps2pdf13]=&quot;!*.@(?(e)ps|pdf)&quot; [ps2pdf12]=&quot;!*.@(?(e)ps|pdf)&quot; [kwrite]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [latex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kate]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pbzcat]=&quot;!*.?(t)bz?(2)&quot; [poedit]=&quot;!*.po&quot; [view]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [mozilla-firefox]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [kid3-qt]=&quot;!*.@(mp[234c]|og[ag]|@(fl|a)ac|m4[abp]|spx|tta|w?(a)v|wma|aif?(f)|asf|ape)&quot; [luatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [bunzip2]=&quot;!*.?(t)bz?(2)&quot; [chromium-browser]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [dvipdfm]=&quot;!*.dvi&quot; [kbabel]=&quot;!*.po&quot; [ly2dvi]=&quot;!*.ly&quot; [oodraw]=&quot;!*.@(sxd|std|sda|sdd|?(f)odg|otg)&quot; [bzme]=&quot;!*.@(zip|z|gz|tgz)&quot; [rgview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [pdftex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [xemacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zathura]=&quot;!*.@(cb[rz7t]|djv?(u)|?(e)ps|pdf)&quot; [unxz]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [rvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [madplay]=&quot;!*.mp3&quot; [xetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [gvim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kaffeine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM|iso|ISO)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dviselect]=&quot;!*.dvi&quot; [kpdf]=&quot;!*.@(?(e)ps|pdf)&quot; [bibtex]=&quot;!*.aux&quot; [realplay]=&quot;!*.@(rm?(j)|ra?(m)|smi?(l))&quot; [mpg123]=&quot;!*.mp3&quot; [netscape]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [lzegrep]=&quot;!*.@(tlz|lzma)&quot; [gview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [kdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xv]=&quot;!*.@(gif|jp?(e)g?(2)|j2[ck]|jp[2f]|tif?(f)|png|p[bgp]m|bmp|x[bp]m|rle|rgb|pcx|fits|pm|?(e)ps)&quot; [lzfgrep]=&quot;!*.@(tlz|lzma)&quot; [playmidi]=&quot;!*.@(mid?(i)|cmf)&quot; [lzless]=&quot;!*.@(tlz|lzma)&quot; [elinks]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [timidity]=&quot;!*.@(mid?(i)|rmi|rcp|[gr]36|g18|mod|xm|it|x3m|s[3t]m|kar)&quot; [xdvi]=&quot;!*.@(dvi|DVI)?(.@(gz|Z|bz2))&quot; [xfig]=&quot;!*.fig&quot; [xpdf]=&quot;!*.@(pdf|fdf)?(.@(gz|GZ|bz2|BZ2|Z))&quot; [lomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [lzcat]=&quot;!*.@(tlz|lzma)&quot; [compress]=&quot;*.Z&quot; [pdfjadetex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [kghostview]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [zcat]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [pbunzip2]=&quot;!*.?(t)bz?(2)&quot; [oobase]=&quot;!*.odb&quot; [cdiff]=&quot;!*.@(dif?(f)|?(d)patch)?(.@([gx]z|bz2|lzma))&quot; [iceweasel]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [gtranslator]=&quot;!*.po&quot; [lynx]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [emacs]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [zipinfo]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [google-chrome]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL])|[pP][dD][fF])&quot; [xelatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [uncompress]=&quot;!*.Z&quot; [xzcat]=&quot;!*.@(?(t)xz|tlz|lzma)&quot; [unzip]=&quot;!*.@(zip|[egjsw]ar|exe|pk3|wsz|zargo|xpi|s[tx][cdiw]|sx[gm]|o[dt][tspgfc]|od[bm]|oxt|epub|apk|ipa|do[ct][xm]|p[op]t[mx]|xl[st][xm]|pyz)&quot; [rview]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ogg123]=&quot;!*.@(og[ag]|m3u|flac|spx)&quot; [lrunzip]=&quot;!*.lrz&quot; [lzgrep]=&quot;!*.@(tlz|lzma)&quot; [slitex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [vim]=&quot;*.@([ao]|so|so.!(conf|*/*)|[rs]pm|gif|jp?(e)g|mp3|mp?(e)g|avi|asf|ogg|class)&quot; [ggv]=&quot;!*.@(@(?(e)ps|?(E)PS|pdf|PDF)?(.gz|.GZ|.bz2|.BZ2|.Z))&quot; [ee]=&quot;!*.@(gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx)&quot; [oomath]=&quot;!*.@(sxm|smf|mml|odf)&quot; [aaxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; [dvipdfmx]=&quot;!*.dvi&quot; [advi]=&quot;!*.dvi&quot; [gunzip]=&quot;!*.@(Z|[gGd]z|t[ag]z)&quot; [makeinfo]=&quot;!*.texi*&quot; [gharbour]=&quot;!*.@([Pp][Rr][Gg]|[Cc][Ll][Pp])&quot; [okular]=&quot;!*.@(okular|@(?(e|x)ps|?(E|X)PS|[pf]df|[PF]DF|dvi|DVI|cb[rz]|CB[RZ]|djv?(u)|DJV?(U)|dvi|DVI|gif|jp?(e)g|miff|tif?(f)|pn[gm]|p[bgp]m|bmp|xpm|ico|xwd|tga|pcx|GIF|JP?(E)G|MIFF|TIF?(F)|PN[GM]|P[BGP]M|BMP|XPM|ICO|XWD|TGA|PCX|epub|EPUB|odt|ODT|fb?(2)|FB?(2)|mobi|MOBI|g3|G3|chm|CHM)?(.?(gz|GZ|bz2|BZ2)))&quot; [galeon]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [pdflatex]=&quot;!*.@(?(la)tex|texi|dtx|ins|ltx|dbj)&quot; [lzmore]=&quot;!*.@(tlz|lzma)&quot; [portecle]=&quot;!@(*.@(ks|jks|jceks|p12|pfx|bks|ubr|gkr|cer|crt|cert|p7b|pkipath|pem|p10|csr|crl)|cacerts)&quot; [oowriter]=&quot;!*.@(sxw|stw|sxg|sgl|doc?([mx])|dot?([mx])|rtf|txt|htm|html|?(f)odt|ott|odm|pdf)&quot; [loimpress]=&quot;!*.@(sxi|sti|pps?(x)|ppt?([mx])|pot?([mx])|?(f)odp|otp)&quot; [epiphany]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [modplugplay]=&quot;!*.@(669|abc|am[fs]|d[bs]m|dmf|far|it|mdl|m[eo]d|mid?(i)|mt[2m]|oct|okt?(a)|p[st]m|s[3t]m|ult|umx|wav|xm)&quot; [dvipdf]=&quot;!*.dvi&quot; [dillo]=&quot;!*.@(?([xX]|[sS])[hH][tT][mM]?([lL]))&quot; [fbxine]=&quot;!*@(.@(mp?(e)g|MP?(E)G|wm[av]|WM[AV]|avi|AVI|asf|vob|VOB|bin|dat|divx|DIVX|vcd|ps|pes|fli|flv|FLV|fxm|FXM|viv|rm|ram|yuv|mov|MOV|qt|QT|web[am]|WEB[AM]|mp[234]|MP[234]|m?(p)4[av]|M?(P)4[AV]|mkv|MKV|og[agmvx]|OG[AGMVX]|t[ps]|T[PS]|m2t?(s)|M2T?(S)|mts|MTS|wav|WAV|flac|FLAC|asx|ASX|mng|MNG|srt|m[eo]d|M[EO]D|s[3t]m|S[3T]M|it|IT|xm|XM)|+([0-9]).@(vdr|VDR))?(.part)&quot; )
__expand_tilde_by_ref () 
{ 
    if [[ ${!1} == \~* ]]; then
        eval $1=$(printf ~%q &quot;${!1#\~}&quot;);
    fi
}
__get_cword_at_cursor_by_ref () 
{ 
    local cword words=();
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    local i cur index=$COMP_POINT lead=${COMP_LINE:0:$COMP_POINT};
    if [[ $index -gt 0 &amp;&amp; ( -n $lead &amp;&amp; -n ${lead//[[:space:]]} ) ]]; then
        cur=$COMP_LINE;
        for ((i = 0; i &lt;= cword; ++i ))
        do
            while [[ ${#cur} -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                cur=&quot;${cur:1}&quot;;
                [[ $index -gt 0 ]] &amp;&amp; ((index--));
            done;
            if [[ $i -lt $cword ]]; then
                local old_size=${#cur};
                cur=&quot;${cur#&quot;${words[i]}&quot;}&quot;;
                local new_size=${#cur};
                index=$(( index - old_size + new_size ));
            fi;
        done;
        [[ -n $cur &amp;&amp; ! -n ${cur//[[:space:]]} ]] &amp;&amp; cur=;
        [[ $index -lt 0 ]] &amp;&amp; index=0;
    fi;
    local &quot;$2&quot; &quot;$3&quot; &quot;$4&quot; &amp;&amp; _upvars -a${#words[@]} $2 &quot;${words[@]}&quot; -v $3 &quot;$cword&quot; -v $4 &quot;${cur:0:$index}&quot;
}
__git_eread () 
{ 
    test -r &quot;$1&quot; &amp;&amp; IFS=&apos;
&apos; read &quot;$2&quot; &lt; &quot;$1&quot;
}
__git_ps1 () 
{ 
    local exit=$?;
    local pcmode=no;
    local detached=no;
    local ps1pc_start=&apos;\u@\h:\w &apos;;
    local ps1pc_end=&apos;\$ &apos;;
    local printf_format=&apos; (%s)&apos;;
    case &quot;$#&quot; in 
        2 | 3)
            pcmode=yes;
            ps1pc_start=&quot;$1&quot;;
            ps1pc_end=&quot;$2&quot;;
            printf_format=&quot;${3:-$printf_format}&quot;;
            PS1=&quot;$ps1pc_start$ps1pc_end&quot;
        ;;
        0 | 1)
            printf_format=&quot;${1:-$printf_format}&quot;
        ;;
        *)
            return $exit
        ;;
    esac;
    local ps1_expanded=yes;
    [ -z &quot;${ZSH_VERSION-}&quot; ] || [[ -o PROMPT_SUBST ]] || ps1_expanded=no;
    [ -z &quot;${BASH_VERSION-}&quot; ] || shopt -q promptvars || ps1_expanded=no;
    local repo_info rev_parse_exit_code;
    repo_info=&quot;$(git rev-parse --git-dir --is-inside-git-dir 		--is-bare-repository --is-inside-work-tree 		--short HEAD 2&gt;/dev/null)&quot;;
    rev_parse_exit_code=&quot;$?&quot;;
    if [ -z &quot;$repo_info&quot; ]; then
        return $exit;
    fi;
    local short_sha=&quot;&quot;;
    if [ &quot;$rev_parse_exit_code&quot; = &quot;0&quot; ]; then
        short_sha=&quot;${repo_info##*
}&quot;;
        repo_info=&quot;${repo_info%
*}&quot;;
    fi;
    local inside_worktree=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local bare_repo=&quot;${repo_info##*
}&quot;;
    repo_info=&quot;${repo_info%
*}&quot;;
    local inside_gitdir=&quot;${repo_info##*
}&quot;;
    local g=&quot;${repo_info%
*}&quot;;
    if [ &quot;true&quot; = &quot;$inside_worktree&quot; ] &amp;&amp; [ -n &quot;${GIT_PS1_HIDE_IF_PWD_IGNORED-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.hideIfPwdIgnored)&quot; != &quot;false&quot; ] &amp;&amp; git check-ignore -q .; then
        return $exit;
    fi;
    local r=&quot;&quot;;
    local b=&quot;&quot;;
    local step=&quot;&quot;;
    local total=&quot;&quot;;
    if [ -d &quot;$g/rebase-merge&quot; ]; then
        __git_eread &quot;$g/rebase-merge/head-name&quot; b;
        __git_eread &quot;$g/rebase-merge/msgnum&quot; step;
        __git_eread &quot;$g/rebase-merge/end&quot; total;
        if [ -f &quot;$g/rebase-merge/interactive&quot; ]; then
            r=&quot;|REBASE-i&quot;;
        else
            r=&quot;|REBASE-m&quot;;
        fi;
    else
        if [ -d &quot;$g/rebase-apply&quot; ]; then
            __git_eread &quot;$g/rebase-apply/next&quot; step;
            __git_eread &quot;$g/rebase-apply/last&quot; total;
            if [ -f &quot;$g/rebase-apply/rebasing&quot; ]; then
                __git_eread &quot;$g/rebase-apply/head-name&quot; b;
                r=&quot;|REBASE&quot;;
            else
                if [ -f &quot;$g/rebase-apply/applying&quot; ]; then
                    r=&quot;|AM&quot;;
                else
                    r=&quot;|AM/REBASE&quot;;
                fi;
            fi;
        else
            if [ -f &quot;$g/MERGE_HEAD&quot; ]; then
                r=&quot;|MERGING&quot;;
            else
                if [ -f &quot;$g/CHERRY_PICK_HEAD&quot; ]; then
                    r=&quot;|CHERRY-PICKING&quot;;
                else
                    if [ -f &quot;$g/REVERT_HEAD&quot; ]; then
                        r=&quot;|REVERTING&quot;;
                    else
                        if [ -f &quot;$g/BISECT_LOG&quot; ]; then
                            r=&quot;|BISECTING&quot;;
                        fi;
                    fi;
                fi;
            fi;
        fi;
        if [ -n &quot;$b&quot; ]; then
            :;
        else
            if [ -h &quot;$g/HEAD&quot; ]; then
                b=&quot;$(git symbolic-ref HEAD 2&gt;/dev/null)&quot;;
            else
                local head=&quot;&quot;;
                if ! __git_eread &quot;$g/HEAD&quot; head; then
                    return $exit;
                fi;
                b=&quot;${head#ref: }&quot;;
                if [ &quot;$head&quot; = &quot;$b&quot; ]; then
                    detached=yes;
                    b=&quot;$(
				case &quot;${GIT_PS1_DESCRIBE_STYLE-}&quot; in
				(contains)
					git describe --contains HEAD ;;
				(branch)
					git describe --contains --all HEAD ;;
				(tag)
					git describe --tags HEAD ;;
				(describe)
					git describe HEAD ;;
				(* | default)
					git describe --tags --exact-match HEAD ;;
				esac 2&gt;/dev/null)&quot; || b=&quot;$short_sha...&quot;;
                    b=&quot;($b)&quot;;
                fi;
            fi;
        fi;
    fi;
    if [ -n &quot;$step&quot; ] &amp;&amp; [ -n &quot;$total&quot; ]; then
        r=&quot;$r $step/$total&quot;;
    fi;
    local w=&quot;&quot;;
    local i=&quot;&quot;;
    local s=&quot;&quot;;
    local u=&quot;&quot;;
    local c=&quot;&quot;;
    local p=&quot;&quot;;
    if [ &quot;true&quot; = &quot;$inside_gitdir&quot; ]; then
        if [ &quot;true&quot; = &quot;$bare_repo&quot; ]; then
            c=&quot;BARE:&quot;;
        else
            b=&quot;GIT_DIR!&quot;;
        fi;
    else
        if [ &quot;true&quot; = &quot;$inside_worktree&quot; ]; then
            if [ -n &quot;${GIT_PS1_SHOWDIRTYSTATE-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showDirtyState)&quot; != &quot;false&quot; ]; then
                git diff --no-ext-diff --quiet || w=&quot;*&quot;;
                git diff --no-ext-diff --cached --quiet || i=&quot;+&quot;;
                if [ -z &quot;$short_sha&quot; ] &amp;&amp; [ -z &quot;$i&quot; ]; then
                    i=&quot;#&quot;;
                fi;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWSTASHSTATE-}&quot; ] &amp;&amp; git rev-parse --verify --quiet refs/stash &gt; /dev/null; then
                s=&quot;$&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUNTRACKEDFILES-}&quot; ] &amp;&amp; [ &quot;$(git config --bool bash.showUntrackedFiles)&quot; != &quot;false&quot; ] &amp;&amp; git ls-files --others --exclude-standard --directory --no-empty-directory --error-unmatch -- &apos;:/*&apos; &gt; /dev/null 2&gt; /dev/null; then
                u=&quot;%${ZSH_VERSION+%}&quot;;
            fi;
            if [ -n &quot;${GIT_PS1_SHOWUPSTREAM-}&quot; ]; then
                __git_ps1_show_upstream;
            fi;
        fi;
    fi;
    local z=&quot;${GIT_PS1_STATESEPARATOR-&quot; &quot;}&quot;;
    if [ $pcmode = yes ] &amp;&amp; [ -n &quot;${GIT_PS1_SHOWCOLORHINTS-}&quot; ]; then
        __git_ps1_colorize_gitstring;
    fi;
    b=${b##refs/heads/};
    if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
        __git_ps1_branch_name=$b;
        b=&quot;\${__git_ps1_branch_name}&quot;;
    fi;
    local f=&quot;$w$i$s$u&quot;;
    local gitstring=&quot;$c$b${f:+$z$f}$r$p&quot;;
    if [ $pcmode = yes ]; then
        if [ &quot;${__git_printf_supports_v-}&quot; != yes ]; then
            gitstring=$(printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;);
        else
            printf -v gitstring -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
        fi;
        PS1=&quot;$ps1pc_start$gitstring$ps1pc_end&quot;;
    else
        printf -- &quot;$printf_format&quot; &quot;$gitstring&quot;;
    fi;
    return $exit
}
__git_ps1_colorize_gitstring () 
{ 
    if [[ -n ${ZSH_VERSION-} ]]; then
        local c_red=&apos;%F{red}&apos;;
        local c_green=&apos;%F{green}&apos;;
        local c_lblue=&apos;%F{blue}&apos;;
        local c_clear=&apos;%f&apos;;
    else
        local c_red=&apos;\[\e[31m\]&apos;;
        local c_green=&apos;\[\e[32m\]&apos;;
        local c_lblue=&apos;\[\e[1;34m\]&apos;;
        local c_clear=&apos;\[\e[0m\]&apos;;
    fi;
    local bad_color=$c_red;
    local ok_color=$c_green;
    local flags_color=&quot;$c_lblue&quot;;
    local branch_color=&quot;&quot;;
    if [ $detached = no ]; then
        branch_color=&quot;$ok_color&quot;;
    else
        branch_color=&quot;$bad_color&quot;;
    fi;
    c=&quot;$branch_color$c&quot;;
    z=&quot;$c_clear$z&quot;;
    if [ &quot;$w&quot; = &quot;*&quot; ]; then
        w=&quot;$bad_color$w&quot;;
    fi;
    if [ -n &quot;$i&quot; ]; then
        i=&quot;$ok_color$i&quot;;
    fi;
    if [ -n &quot;$s&quot; ]; then
        s=&quot;$flags_color$s&quot;;
    fi;
    if [ -n &quot;$u&quot; ]; then
        u=&quot;$bad_color$u&quot;;
    fi;
    r=&quot;$c_clear$r&quot;
}
__git_ps1_show_upstream () 
{ 
    local key value;
    local svn_remote svn_url_pattern count n;
    local upstream=git legacy=&quot;&quot; verbose=&quot;&quot; name=&quot;&quot;;
    svn_remote=();
    local output=&quot;$(git config -z --get-regexp &apos;^(svn-remote\..*\.url|bash\.showupstream)$&apos; 2&gt;/dev/null | tr &apos;\0\n&apos; &apos;\n &apos;)&quot;;
    while read -r key value; do
        case &quot;$key&quot; in 
            bash.showupstream)
                GIT_PS1_SHOWUPSTREAM=&quot;$value&quot;;
                if [[ -z &quot;${GIT_PS1_SHOWUPSTREAM}&quot; ]]; then
                    p=&quot;&quot;;
                    return;
                fi
            ;;
            svn-remote.*.url)
                svn_remote[$((${#svn_remote[@]} + 1))]=&quot;$value&quot;;
                svn_url_pattern=&quot;$svn_url_pattern\\|$value&quot;;
                upstream=svn+git
            ;;
        esac;
    done &lt;&lt;&lt; &quot;$output&quot;;
    for option in ${GIT_PS1_SHOWUPSTREAM};
    do
        case &quot;$option&quot; in 
            git | svn)
                upstream=&quot;$option&quot;
            ;;
            verbose)
                verbose=1
            ;;
            legacy)
                legacy=1
            ;;
            name)
                name=1
            ;;
        esac;
    done;
    case &quot;$upstream&quot; in 
        git)
            upstream=&quot;@{upstream}&quot;
        ;;
        svn*)
            local -a svn_upstream;
            svn_upstream=($(git log --first-parent -1 				--grep=&quot;^git-svn-id: \(${svn_url_pattern#??}\)&quot; 2&gt;/dev/null));
            if [[ 0 -ne ${#svn_upstream[@]} ]]; then
                svn_upstream=${svn_upstream[${#svn_upstream[@]} - 2]};
                svn_upstream=${svn_upstream%@*};
                local n_stop=&quot;${#svn_remote[@]}&quot;;
                for ((n=1; n &lt;= n_stop; n++))
                do
                    svn_upstream=${svn_upstream#${svn_remote[$n]}};
                done;
                if [[ -z &quot;$svn_upstream&quot; ]]; then
                    upstream=${GIT_SVN_ID:-git-svn};
                else
                    upstream=${svn_upstream#/};
                fi;
            else
                if [[ &quot;svn+git&quot; = &quot;$upstream&quot; ]]; then
                    upstream=&quot;@{upstream}&quot;;
                fi;
            fi
        ;;
    esac;
    if [[ -z &quot;$legacy&quot; ]]; then
        count=&quot;$(git rev-list --count --left-right 				&quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;;
    else
        local commits;
        if commits=&quot;$(git rev-list --left-right &quot;$upstream&quot;...HEAD 2&gt;/dev/null)&quot;; then
            local commit behind=0 ahead=0;
            for commit in $commits;
            do
                case &quot;$commit&quot; in 
                    &quot;&lt;&quot;*)
                        ((behind++))
                    ;;
                    *)
                        ((ahead++))
                    ;;
                esac;
            done;
            count=&quot;$behind	$ahead&quot;;
        else
            count=&quot;&quot;;
        fi;
    fi;
    if [[ -z &quot;$verbose&quot; ]]; then
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot;=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot;&gt;&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot;&lt;&quot;
            ;;
            *)
                p=&quot;&lt;&gt;&quot;
            ;;
        esac;
    else
        case &quot;$count&quot; in 
            &quot;&quot;)
                p=&quot;&quot;
            ;;
            &quot;0	0&quot;)
                p=&quot; u=&quot;
            ;;
            &quot;0	&quot;*)
                p=&quot; u+${count#0	}&quot;
            ;;
            *&quot;	0&quot;)
                p=&quot; u-${count%	0}&quot;
            ;;
            *)
                p=&quot; u+${count#*	}-${count%	*}&quot;
            ;;
        esac;
        if [[ -n &quot;$count&quot; &amp;&amp; -n &quot;$name&quot; ]]; then
            __git_ps1_upstream_name=$(git rev-parse 				--abbrev-ref &quot;$upstream&quot; 2&gt;/dev/null);
            if [ $pcmode = yes ] &amp;&amp; [ $ps1_expanded = yes ]; then
                p=&quot;$p \${__git_ps1_upstream_name}&quot;;
            else
                p=&quot;$p ${__git_ps1_upstream_name}&quot;;
                unset __git_ps1_upstream_name;
            fi;
        fi;
    fi
}
__load_completion () 
{ 
    local -a dirs=(${BASH_COMPLETION_USER_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/bash-completion}/completions);
    local OIFS=$IFS IFS=: dir cmd=&quot;${1##*/}&quot; compfile;
    [[ -n $cmd ]] || return 1;
    for dir in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share};
    do
        dirs+=($dir/bash-completion/completions);
    done;
    IFS=$OIFS;
    if [[ $BASH_SOURCE == */* ]]; then
        dirs+=(&quot;${BASH_SOURCE%/*}/completions&quot;);
    else
        dirs+=(./completions);
    fi;
    for dir in &quot;${dirs[@]}&quot;;
    do
        for compfile in &quot;$cmd&quot; &quot;$cmd.bash&quot; &quot;_$cmd&quot;;
        do
            compfile=&quot;$dir/$compfile&quot;;
            [[ -f &quot;$compfile&quot; ]] &amp;&amp; . &quot;$compfile&quot; &amp;&gt; /dev/null &amp;&amp; return 0;
        done;
    done;
    [[ -n &quot;${_xspecs[$cmd]}&quot; ]] &amp;&amp; complete -F _filedir_xspec &quot;$cmd&quot; &amp;&amp; return 0;
    return 1
}
__ltrim_colon_completions () 
{ 
    if [[ &quot;$1&quot; == *:* &amp;&amp; &quot;$COMP_WORDBREAKS&quot; == *:* ]]; then
        local colon_word=${1%&quot;${1##*:}&quot;};
        local i=${#COMPREPLY[*]};
        while [[ $((--i)) -ge 0 ]]; do
            COMPREPLY[$i]=${COMPREPLY[$i]#&quot;$colon_word&quot;};
        done;
    fi
}
__parse_options () 
{ 
    local option option2 i IFS=&apos; 	
,/|&apos;;
    option=;
    local -a array;
    read -a array &lt;&lt;&lt; &quot;$1&quot;;
    for i in &quot;${array[@]}&quot;;
    do
        case &quot;$i&quot; in 
            ---*)
                break
            ;;
            --?*)
                option=$i;
                break
            ;;
            -?*)
                [[ -n $option ]] || option=$i
            ;;
            *)
                break
            ;;
        esac;
    done;
    [[ -n $option ]] || return;
    IFS=&apos; 	
&apos;;
    if [[ $option =~ (\[((no|dont)-?)\]). ]]; then
        option2=${option/&quot;${BASH_REMATCH[1]}&quot;/};
        option2=${option2%%[&lt;{().[]*};
        printf &apos;%s\n&apos; &quot;${option2/=*/=}&quot;;
        option=${option/&quot;${BASH_REMATCH[1]}&quot;/&quot;${BASH_REMATCH[2]}&quot;};
    fi;
    option=${option%%[&lt;{().[]*};
    printf &apos;%s\n&apos; &quot;${option/=*/=}&quot;
}
__reassemble_comp_words_by_ref () 
{ 
    local exclude i j line ref;
    if [[ -n $1 ]]; then
        exclude=&quot;${1//[^$COMP_WORDBREAKS]}&quot;;
    fi;
    printf -v &quot;$3&quot; %s &quot;$COMP_CWORD&quot;;
    if [[ -n $exclude ]]; then
        line=$COMP_LINE;
        for ((i=0, j=0; i &lt; ${#COMP_WORDS[@]}; i++, j++))
        do
            while [[ $i -gt 0 &amp;&amp; ${COMP_WORDS[$i]} == +([$exclude]) ]]; do
                [[ $line != [[:blank:]]* ]] &amp;&amp; (( j &gt;= 2 )) &amp;&amp; ((j--));
                ref=&quot;$2[$j]&quot;;
                printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
                [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
                line=${line#*&quot;${COMP_WORDS[$i]}&quot;};
                [[ $line == [[:blank:]]* ]] &amp;&amp; ((j++));
                (( $i &lt; ${#COMP_WORDS[@]} - 1)) &amp;&amp; ((i++)) || break 2;
            done;
            ref=&quot;$2[$j]&quot;;
            printf -v &quot;$ref&quot; %s &quot;${!ref}${COMP_WORDS[i]}&quot;;
            line=${line#*&quot;${COMP_WORDS[i]}&quot;};
            [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
        done;
        [[ $i == $COMP_CWORD ]] &amp;&amp; printf -v &quot;$3&quot; %s &quot;$j&quot;;
    else
        for i in ${!COMP_WORDS[@]};
        do
            printf -v &quot;$2[i]&quot; %s &quot;${COMP_WORDS[i]}&quot;;
        done;
    fi
}
_allowed_groups () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -g -- &quot;$1&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -Gn 2&gt;/dev/null || groups 2&gt;/dev/null )&quot; -- &quot;$1&quot; ));
    fi
}
_allowed_users () 
{ 
    if _complete_as_root; then
        local IFS=&apos;
&apos;;
        COMPREPLY=($( compgen -u -- &quot;${1:-$cur}&quot; ));
    else
        local IFS=&apos;
 &apos;;
        COMPREPLY=($( compgen -W             &quot;$( id -un 2&gt;/dev/null || whoami 2&gt;/dev/null )&quot; -- &quot;${1:-$cur}&quot; ));
    fi
}
_available_interfaces () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY=($( {
        if [[ ${1:-} == -w ]]; then
            iwconfig
        elif [[ ${1:-} == -a ]]; then
            ifconfig || ip link show up
        else
            ifconfig -a || ip link show
        fi
    } 2&gt;/dev/null | awk         &apos;/^[^ \t]/ { if ($1 ~ /^[0-9]+:/) { print $2 } else { print $1 } }&apos; ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]/%[[:punct:]]/}&apos; -- &quot;$cur&quot; ))
}
_cd () 
{ 
    local cur prev words cword;
    _init_completion || return;
    local IFS=&apos;
&apos; i j k;
    compopt -o filenames;
    if [[ -z &quot;${CDPATH:-}&quot; || &quot;$cur&quot; == ?(.)?(.)/* ]]; then
        _filedir -d;
        return;
    fi;
    local -r mark_dirs=$(_rl_enabled mark-directories &amp;&amp; echo y);
    local -r mark_symdirs=$(_rl_enabled mark-symlinked-directories &amp;&amp; echo y);
    for i in ${CDPATH//:/&apos;
&apos;};
    do
        k=&quot;${#COMPREPLY[@]}&quot;;
        for j in $( compgen -d -- $i/$cur );
        do
            if [[ ( -n $mark_symdirs &amp;&amp; -h $j || -n $mark_dirs &amp;&amp; ! -h $j ) &amp;&amp; ! -d ${j#$i/} ]]; then
                j+=&quot;/&quot;;
            fi;
            COMPREPLY[k++]=${j#$i/};
        done;
    done;
    _filedir -d;
    if [[ ${#COMPREPLY[@]} -eq 1 ]]; then
        i=${COMPREPLY[0]};
        if [[ &quot;$i&quot; == &quot;$cur&quot; &amp;&amp; $i != &quot;*/&quot; ]]; then
            COMPREPLY[0]=&quot;${i}/&quot;;
        fi;
    fi;
    return
}
_cd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?([amrs])cd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_command () 
{ 
    local offset i;
    offset=1;
    for ((i=1; i &lt;= COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            offset=$i;
            break;
        fi;
    done;
    _command_offset $offset
}
_command_offset () 
{ 
    local word_offset=$1 i j;
    for ((i=0; i &lt; $word_offset; i++ ))
    do
        for ((j=0; j &lt;= ${#COMP_LINE}; j++ ))
        do
            [[ &quot;$COMP_LINE&quot; == &quot;${COMP_WORDS[i]}&quot;* ]] &amp;&amp; break;
            COMP_LINE=${COMP_LINE:1};
            ((COMP_POINT--));
        done;
        COMP_LINE=${COMP_LINE#&quot;${COMP_WORDS[i]}&quot;};
        ((COMP_POINT-=${#COMP_WORDS[i]}));
    done;
    for ((i=0; i &lt;= COMP_CWORD - $word_offset; i++ ))
    do
        COMP_WORDS[i]=${COMP_WORDS[i+$word_offset]};
    done;
    for ((i; i &lt;= COMP_CWORD; i++ ))
    do
        unset &apos;COMP_WORDS[i]&apos;;
    done;
    ((COMP_CWORD -= $word_offset));
    COMPREPLY=();
    local cur;
    _get_comp_words_by_ref cur;
    if [[ $COMP_CWORD -eq 0 ]]; then
        local IFS=&apos;
&apos;;
        compopt -o filenames;
        COMPREPLY=($( compgen -d -c -- &quot;$cur&quot; ));
    else
        local cmd=${COMP_WORDS[0]} compcmd=${COMP_WORDS[0]};
        local cspec=$( complete -p $cmd 2&gt;/dev/null );
        if [[ ! -n $cspec &amp;&amp; $cmd == */* ]]; then
            cspec=$( complete -p ${cmd##*/} 2&gt;/dev/null );
            [[ -n $cspec ]] &amp;&amp; compcmd=${cmd##*/};
        fi;
        if [[ ! -n $cspec ]]; then
            compcmd=${cmd##*/};
            _completion_loader $compcmd;
            cspec=$( complete -p $compcmd 2&gt;/dev/null );
        fi;
        if [[ -n $cspec ]]; then
            if [[ ${cspec#* -F } != $cspec ]]; then
                local func=${cspec#*-F };
                func=${func%% *};
                if [[ ${#COMP_WORDS[@]} -ge 2 ]]; then
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot; &quot;${COMP_WORDS[${#COMP_WORDS[@]}-2]}&quot;;
                else
                    $func $cmd &quot;${COMP_WORDS[${#COMP_WORDS[@]}-1]}&quot;;
                fi;
                local opt;
                while [[ $cspec == *&quot; -o &quot;* ]]; do
                    cspec=${cspec#*-o };
                    opt=${cspec%% *};
                    compopt -o $opt;
                    cspec=${cspec#$opt};
                done;
            else
                cspec=${cspec#complete};
                cspec=${cspec%%$compcmd};
                COMPREPLY=($( eval compgen &quot;$cspec&quot; -- &apos;$cur&apos; ));
            fi;
        else
            if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
                _minimal;
            fi;
        fi;
    fi
}
_complete_as_root () 
{ 
    [[ $EUID -eq 0 || -n ${root_command:-} ]]
}
_completion_loader () 
{ 
    local cmd=&quot;${1:-_EmptycmD_}&quot;;
    __load_completion &quot;$cmd&quot; &amp;&amp; return 124;
    complete -F _minimal -- &quot;$cmd&quot; &amp;&amp; return 124
}
_configured_interfaces () 
{ 
    if [[ -f /etc/debian_version ]]; then
        COMPREPLY=($( compgen -W &quot;$( command sed -ne &apos;s|^iface \([^ ]\{1,\}\).*$|\1|p&apos;            /etc/network/interfaces /etc/network/interfaces.d/* 2&gt;/dev/null )&quot;             -- &quot;$cur&quot; ));
    else
        if [[ -f /etc/SuSE-release ]]; then
            COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
        else
            if [[ -f /etc/pld-release ]]; then
                COMPREPLY=($( compgen -W &quot;$( command ls -B             /etc/sysconfig/interfaces |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            else
                COMPREPLY=($( compgen -W &quot;$( printf &apos;%s\n&apos;             /etc/sysconfig/network-scripts/ifcfg-* |             command sed -ne &apos;s|.*ifcfg-\([^*].*\)$|\1|p&apos; )&quot; -- &quot;$cur&quot; ));
            fi;
        fi;
    fi
}
_count_args () 
{ 
    local i cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    args=1;
    for i in &quot;${words[@]:1:cword-1}&quot;;
    do
        [[ &quot;$i&quot; != -* ]] &amp;&amp; args=$(($args+1));
    done
}
_dvd_devices () 
{ 
    COMPREPLY+=($( compgen -f -d -X &quot;!*/?(r)dvd*&quot; -- &quot;${cur:-/dev/}&quot; ))
}
_expand () 
{ 
    if [[ &quot;$cur&quot; == \~*/* ]]; then
        __expand_tilde_by_ref cur;
    else
        if [[ &quot;$cur&quot; == \~* ]]; then
            _tilde &quot;$cur&quot; || eval COMPREPLY[0]=$(printf ~%q &quot;${COMPREPLY[0]#\~}&quot;);
            return ${#COMPREPLY[@]};
        fi;
    fi
}
_filedir () 
{ 
    local IFS=&apos;
&apos;;
    _tilde &quot;$cur&quot; || return;
    local -a toks;
    local x reset;
    reset=$(shopt -po noglob);
    set -o noglob;
    toks=($( compgen -d -- &quot;$cur&quot; ));
    eval $reset;
    if [[ &quot;$1&quot; != -d ]]; then
        local quoted;
        _quote_readline_by_ref &quot;$cur&quot; quoted;
        local xspec=${1:+&quot;!*.@($1|${1^^})&quot;};
        reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -X &quot;$xspec&quot; -- $quoted ));
        eval $reset;
        [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; -n &quot;$1&quot; &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
            reset=$(shopt -po noglob);
            set -o noglob;
            toks+=($( compgen -f -- $quoted ));
            eval $reset
        };
    fi;
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames 2&gt; /dev/null;
        COMPREPLY+=(&quot;${toks[@]}&quot;);
    fi
}
_filedir_xspec () 
{ 
    local cur prev words cword;
    _init_completion || return;
    _tilde &quot;$cur&quot; || return;
    local IFS=&apos;
&apos; xspec=${_xspecs[${1##*/}]} tmp;
    local -a toks;
    toks=($(
        compgen -d -- &quot;$(quote_readline &quot;$cur&quot;)&quot; | {
        while read -r tmp; do
            printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    eval xspec=&quot;${xspec}&quot;;
    local matchop=!;
    if [[ $xspec == !* ]]; then
        xspec=${xspec#!};
        matchop=@;
    fi;
    xspec=&quot;$matchop($xspec|${xspec^^})&quot;;
    toks+=($(
        eval compgen -f -X &quot;&apos;!$xspec&apos;&quot; -- &quot;\$(quote_readline &quot;\$cur&quot;)&quot; | {
        while read -r tmp; do
            [[ -n $tmp ]] &amp;&amp; printf &apos;%s\n&apos; $tmp
        done
        }
        ));
    [[ -n ${COMP_FILEDIR_FALLBACK:-} &amp;&amp; ${#toks[@]} -lt 1 ]] &amp;&amp; { 
        local reset=$(shopt -po noglob);
        set -o noglob;
        toks+=($( compgen -f -- &quot;$(quote_readline &quot;$cur&quot;)&quot; ));
        IFS=&apos; &apos;;
        $reset;
        IFS=&apos;
&apos;
    };
    if [[ ${#toks[@]} -ne 0 ]]; then
        compopt -o filenames;
        COMPREPLY=(&quot;${toks[@]}&quot;);
    fi
}
_fstypes () 
{ 
    local fss;
    if [[ -e /proc/filesystems ]]; then
        fss=&quot;$( cut -d&apos;	&apos; -f2 /proc/filesystems )
            $( awk &apos;! /\*/ { print $NF }&apos; /etc/filesystems 2&gt;/dev/null )&quot;;
    else
        fss=&quot;$( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/fstab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $3 }&apos; /etc/mnttab 2&gt;/dev/null )
            $( awk &apos;/^[ \t]*[^#]/ { print $4 }&apos; /etc/vfstab 2&gt;/dev/null )
            $( awk &apos;{ print $1 }&apos; /etc/dfs/fstypes 2&gt;/dev/null )
            $( [[ -d /etc/fs ]] &amp;&amp; command ls /etc/fs )&quot;;
    fi;
    [[ -n $fss ]] &amp;&amp; COMPREPLY+=($( compgen -W &quot;$fss&quot; -- &quot;$cur&quot; ))
}
_get_comp_words_by_ref () 
{ 
    local exclude flag i OPTIND=1;
    local cur cword words=();
    local upargs=() upvars=() vcur vcword vprev vwords;
    while getopts &quot;c:i:n:p:w:&quot; flag &quot;$@&quot;; do
        case $flag in 
            c)
                vcur=$OPTARG
            ;;
            i)
                vcword=$OPTARG
            ;;
            n)
                exclude=$OPTARG
            ;;
            p)
                vprev=$OPTARG
            ;;
            w)
                vwords=$OPTARG
            ;;
        esac;
    done;
    while [[ $# -ge $OPTIND ]]; do
        case ${!OPTIND} in 
            cur)
                vcur=cur
            ;;
            prev)
                vprev=prev
            ;;
            cword)
                vcword=cword
            ;;
            words)
                vwords=words
            ;;
            *)
                echo &quot;bash: $FUNCNAME(): \`${!OPTIND}&apos;: unknown argument&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
        let &quot;OPTIND += 1&quot;;
    done;
    __get_cword_at_cursor_by_ref &quot;$exclude&quot; words cword cur;
    [[ -n $vcur ]] &amp;&amp; { 
        upvars+=(&quot;$vcur&quot;);
        upargs+=(-v $vcur &quot;$cur&quot;)
    };
    [[ -n $vcword ]] &amp;&amp; { 
        upvars+=(&quot;$vcword&quot;);
        upargs+=(-v $vcword &quot;$cword&quot;)
    };
    [[ -n $vprev &amp;&amp; $cword -ge 1 ]] &amp;&amp; { 
        upvars+=(&quot;$vprev&quot;);
        upargs+=(-v $vprev &quot;${words[cword - 1]}&quot;)
    };
    [[ -n $vwords ]] &amp;&amp; { 
        upvars+=(&quot;$vwords&quot;);
        upargs+=(-a${#words[@]} $vwords &quot;${words[@]}&quot;)
    };
    (( ${#upvars[@]} )) &amp;&amp; local &quot;${upvars[@]}&quot; &amp;&amp; _upvars &quot;${upargs[@]}&quot;
}
_get_cword () 
{ 
    local LC_CTYPE=C;
    local cword words;
    __reassemble_comp_words_by_ref &quot;$1&quot; words cword;
    if [[ -n ${2//[^0-9]/} ]]; then
        printf &quot;%s&quot; &quot;${words[cword-$2]}&quot;;
    else
        if [[ &quot;${#words[cword]}&quot; -eq 0 || &quot;$COMP_POINT&quot; == &quot;${#COMP_LINE}&quot; ]]; then
            printf &quot;%s&quot; &quot;${words[cword]}&quot;;
        else
            local i;
            local cur=&quot;$COMP_LINE&quot;;
            local index=&quot;$COMP_POINT&quot;;
            for ((i = 0; i &lt;= cword; ++i ))
            do
                while [[ &quot;${#cur}&quot; -ge ${#words[i]} &amp;&amp; &quot;${cur:0:${#words[i]}}&quot; != &quot;${words[i]}&quot; ]]; do
                    cur=&quot;${cur:1}&quot;;
                    [[ $index -gt 0 ]] &amp;&amp; ((index--));
                done;
                if [[ &quot;$i&quot; -lt &quot;$cword&quot; ]]; then
                    local old_size=&quot;${#cur}&quot;;
                    cur=&quot;${cur#${words[i]}}&quot;;
                    local new_size=&quot;${#cur}&quot;;
                    index=$(( index - old_size + new_size ));
                fi;
            done;
            if [[ &quot;${words[cword]:0:${#cur}}&quot; != &quot;$cur&quot; ]]; then
                printf &quot;%s&quot; &quot;${words[cword]}&quot;;
            else
                printf &quot;%s&quot; &quot;${cur:0:$index}&quot;;
            fi;
        fi;
    fi
}
_get_first_arg () 
{ 
    local i;
    arg=;
    for ((i=1; i &lt; COMP_CWORD; i++ ))
    do
        if [[ &quot;${COMP_WORDS[i]}&quot; != -* ]]; then
            arg=${COMP_WORDS[i]};
            break;
        fi;
    done
}
_get_pword () 
{ 
    if [[ $COMP_CWORD -ge 1 ]]; then
        _get_cword &quot;${@:-}&quot; 1;
    fi
}
_gids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent group | cut -d: -f3 )&apos;             -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($gid) = (getgrent)[2]) { print $gid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/group )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_have () 
{ 
    PATH=$PATH:/usr/sbin:/sbin:/usr/local/sbin type $1 &amp;&gt; /dev/null
}
_included_ssh_config_files () 
{ 
    [[ $# -lt 1 ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CONFIG&quot;;
    local configfile i f;
    configfile=$1;
    local included=$( command sed -ne &apos;s/^[[:blank:]]*[Ii][Nn][Cc][Ll][Uu][Dd][Ee][[:blank:]]\{1,\}\([^#%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${configfile}&quot; );
    for i in ${included[@]};
    do
        if ! [[ &quot;$i&quot; =~ ^\~.*|^\/.* ]]; then
            if [[ &quot;$configfile&quot; =~ ^\/etc\/ssh.* ]]; then
                i=&quot;/etc/ssh/$i&quot;;
            else
                i=&quot;$HOME/.ssh/$i&quot;;
            fi;
        fi;
        __expand_tilde_by_ref i;
        for f in ${i};
        do
            if [ -r $f ]; then
                config+=(&quot;$f&quot;);
                _included_ssh_config_files $f;
            fi;
        done;
    done
}
_init_completion () 
{ 
    local exclude= flag outx errx inx OPTIND=1;
    while getopts &quot;n:e:o:i:s&quot; flag &quot;$@&quot;; do
        case $flag in 
            n)
                exclude+=$OPTARG
            ;;
            e)
                errx=$OPTARG
            ;;
            o)
                outx=$OPTARG
            ;;
            i)
                inx=$OPTARG
            ;;
            s)
                split=false;
                exclude+==
            ;;
        esac;
    done;
    COMPREPLY=();
    local redir=&quot;@(?([0-9])&lt;|?([0-9&amp;])&gt;?(&gt;)|&gt;&amp;)&quot;;
    _get_comp_words_by_ref -n &quot;$exclude&lt;&gt;&amp;&quot; cur prev words cword;
    _variables &amp;&amp; return 1;
    if [[ $cur == $redir* || $prev == $redir ]]; then
        local xspec;
        case $cur in 
            2&apos;&gt;&apos;*)
                xspec=$errx
            ;;
            *&apos;&gt;&apos;*)
                xspec=$outx
            ;;
            *&apos;&lt;&apos;*)
                xspec=$inx
            ;;
            *)
                case $prev in 
                    2&apos;&gt;&apos;*)
                        xspec=$errx
                    ;;
                    *&apos;&gt;&apos;*)
                        xspec=$outx
                    ;;
                    *&apos;&lt;&apos;*)
                        xspec=$inx
                    ;;
                esac
            ;;
        esac;
        cur=&quot;${cur##$redir}&quot;;
        _filedir $xspec;
        return 1;
    fi;
    local i skip;
    for ((i=1; i &lt; ${#words[@]}; 1))
    do
        if [[ ${words[i]} == $redir* ]]; then
            [[ ${words[i]} == $redir ]] &amp;&amp; skip=2 || skip=1;
            words=(&quot;${words[@]:0:i}&quot; &quot;${words[@]:i+skip}&quot;);
            [[ $i -le $cword ]] &amp;&amp; cword=$(( cword - skip ));
        else
            i=$(( ++i ));
        fi;
    done;
    [[ $cword -le 0 ]] &amp;&amp; return 1;
    prev=${words[cword-1]};
    [[ -n ${split-} ]] &amp;&amp; _split_longopt &amp;&amp; split=true;
    return 0
}
_installed_modules () 
{ 
    COMPREPLY=($( compgen -W &quot;$( PATH=&quot;$PATH:/sbin&quot; lsmod |         awk &apos;{if (NR != 1) print $1}&apos; )&quot; -- &quot;$1&quot; ))
}
_ip_addresses () 
{ 
    local PATH=$PATH:/sbin;
    COMPREPLY+=($( compgen -W         &quot;$( { LC_ALL=C ifconfig -a || ip addr show; } 2&gt;/dev/null | command sed -ne             &apos;s/.*addr:\([^[:space:]]*\).*/\1/p&apos; -ne             &apos;s|.*inet[[:space:]]\{1,\}\([^[:space:]/]*\).*|\1|p&apos; )&quot;         -- &quot;$cur&quot; ))
}
_kernel_versions () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ls /lib/modules )&apos; -- &quot;$cur&quot; ))
}
_known_hosts () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    local options;
    [[ &quot;$1&quot; == -a || &quot;$2&quot; == -a ]] &amp;&amp; options=-a;
    [[ &quot;$1&quot; == -c || &quot;$2&quot; == -c ]] &amp;&amp; options+=&quot; -c&quot;;
    _known_hosts_real $options -- &quot;$cur&quot;
}
_known_hosts_real () 
{ 
    local configfile flag prefix OIFS=$IFS;
    local cur user suffix aliases i host ipv4 ipv6;
    local -a kh tmpkh khd config;
    local OPTIND=1;
    while getopts &quot;ac46F:p:&quot; flag &quot;$@&quot;; do
        case $flag in 
            a)
                aliases=&apos;yes&apos;
            ;;
            c)
                suffix=&apos;:&apos;
            ;;
            F)
                configfile=$OPTARG
            ;;
            p)
                prefix=$OPTARG
            ;;
            4)
                ipv4=1
            ;;
            6)
                ipv6=1
            ;;
        esac;
    done;
    [[ $# -lt $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME: missing mandatory argument CWORD&quot;;
    cur=${!OPTIND};
    let &quot;OPTIND += 1&quot;;
    [[ $# -ge $OPTIND ]] &amp;&amp; echo &quot;error: $FUNCNAME(&quot;$@&quot;): unprocessed arguments:&quot; $(while [[ $# -ge $OPTIND ]]; do printf &apos;%s\n&apos; ${!OPTIND}; shift; done);
    [[ $cur == *@* ]] &amp;&amp; user=${cur%@*}@ &amp;&amp; cur=${cur#*@};
    kh=();
    if [[ -n $configfile ]]; then
        [[ -r $configfile ]] &amp;&amp; config+=(&quot;$configfile&quot;);
    else
        for i in /etc/ssh/ssh_config ~/.ssh/config ~/.ssh2/config;
        do
            [[ -r $i ]] &amp;&amp; config+=(&quot;$i&quot;);
        done;
    fi;
    for i in &quot;${config[@]}&quot;;
    do
        _included_ssh_config_files &quot;$i&quot;;
    done;
    if [[ ${#config[@]} -gt 0 ]]; then
        local IFS=&apos;
&apos; j;
        tmpkh=($( awk &apos;sub(&quot;^[ \t]*([Gg][Ll][Oo][Bb][Aa][Ll]|[Uu][Ss][Ee][Rr])[Kk][Nn][Oo][Ww][Nn][Hh][Oo][Ss][Tt][Ss][Ff][Ii][Ll][Ee][ \t]+&quot;, &quot;&quot;) { print $0 }&apos; &quot;${config[@]}&quot; | sort -u ));
        IFS=$OIFS;
        for i in &quot;${tmpkh[@]}&quot;;
        do
            while [[ $i =~ ^([^\&quot;]*)\&quot;([^\&quot;]*)\&quot;(.*)$ ]]; do
                i=${BASH_REMATCH[1]}${BASH_REMATCH[3]};
                j=${BASH_REMATCH[2]};
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
            for j in $i;
            do
                __expand_tilde_by_ref j;
                [[ -r $j ]] &amp;&amp; kh+=(&quot;$j&quot;);
            done;
        done;
    fi;
    if [[ -z $configfile ]]; then
        for i in /etc/ssh/ssh_known_hosts /etc/ssh/ssh_known_hosts2 /etc/known_hosts /etc/known_hosts2 ~/.ssh/known_hosts ~/.ssh/known_hosts2;
        do
            [[ -r $i ]] &amp;&amp; kh+=(&quot;$i&quot;);
        done;
        for i in /etc/ssh2/knownhosts ~/.ssh2/hostkeys;
        do
            [[ -d $i ]] &amp;&amp; khd+=(&quot;$i&quot;/*pub);
        done;
    fi;
    if [[ ${#kh[@]} -gt 0 || ${#khd[@]} -gt 0 ]]; then
        if [[ ${#kh[@]} -gt 0 ]]; then
            for i in &quot;${kh[@]}&quot;;
            do
                while read -ra tmpkh; do
                    set -- &quot;${tmpkh[@]}&quot;;
                    [[ $1 == [\|\#]* ]] &amp;&amp; continue;
                    [[ $1 == @* ]] &amp;&amp; shift;
                    local IFS=,;
                    for host in $1;
                    do
                        [[ $host == *[*?]* ]] &amp;&amp; continue;
                        host=&quot;${host#[}&quot;;
                        host=&quot;${host%]?(:+([0-9]))}&quot;;
                        COMPREPLY+=($host);
                    done;
                    IFS=$OIFS;
                done &lt; &quot;$i&quot;;
            done;
            COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
        fi;
        if [[ ${#khd[@]} -gt 0 ]]; then
            for i in &quot;${khd[@]}&quot;;
            do
                if [[ &quot;$i&quot; == *key_22_$cur*.pub &amp;&amp; -r &quot;$i&quot; ]]; then
                    host=${i/#*key_22_/};
                    host=${host/%.pub/};
                    COMPREPLY+=($host);
                fi;
            done;
        fi;
        for ((i=0; i &lt; ${#COMPREPLY[@]}; i++ ))
        do
            COMPREPLY[i]=$prefix$user${COMPREPLY[i]}$suffix;
        done;
    fi;
    if [[ ${#config[@]} -gt 0 &amp;&amp; -n &quot;$aliases&quot; ]]; then
        local hosts=$( command sed -ne &apos;s/^[[:blank:]]*[Hh][Oo][Ss][Tt][[:blank:]]\{1,\}\([^#*?%]*\)\(#.*\)\{0,1\}$/\1/p&apos; &quot;${config[@]}&quot; );
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot;             -S &quot;$suffix&quot; -W &quot;$hosts&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_AVAHI:-} ]] &amp;&amp; type avahi-browse &amp;&gt; /dev/null; then
        COMPREPLY+=($( compgen -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -W             &quot;$( avahi-browse -cpr _workstation._tcp 2&gt;/dev/null |                 awk -F&apos;;&apos; &apos;/^=/ { print $7 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ));
    fi;
    COMPREPLY+=($( compgen -W         &quot;$( ruptime 2&gt;/dev/null | awk &apos;!/^ruptime:/ { print $1 }&apos; )&quot;         -- &quot;$cur&quot; ));
    if [[ -n ${COMP_KNOWN_HOSTS_WITH_HOSTFILE-1} ]]; then
        COMPREPLY+=($( compgen -A hostname -P &quot;$prefix$user&quot; -S &quot;$suffix&quot; -- &quot;$cur&quot; ));
    fi;
    if [[ -n $ipv4 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/*:*$suffix/}&quot;);
    fi;
    if [[ -n $ipv6 ]]; then
        COMPREPLY=(&quot;${COMPREPLY[@]/+([0-9]).+([0-9]).+([0-9]).+([0-9])$suffix/}&quot;);
    fi;
    if [[ -n $ipv4 || -n $ipv6 ]]; then
        for i in ${!COMPREPLY[@]};
        do
            [[ -n ${COMPREPLY[i]} ]] || unset -v COMPREPLY[i];
        done;
    fi;
    __ltrim_colon_completions &quot;$prefix$user$cur&quot;
}
_longopt () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    case &quot;${prev,,}&quot; in 
        --help | --usage | --version)
            return
        ;;
        --*dir*)
            _filedir -d;
            return
        ;;
        --*file* | --*path*)
            _filedir;
            return
        ;;
        --+([-a-z0-9_]))
            local argtype=$( LC_ALL=C $1 --help 2&gt;&amp;1 | command sed -ne                 &quot;s|.*$prev\[\{0,1\}=[&lt;[]\{0,1\}\([-A-Za-z0-9_]\{1,\}\).*|\1|p&quot; );
            case ${argtype,,} in 
                *dir*)
                    _filedir -d;
                    return
                ;;
                *file* | *path*)
                    _filedir;
                    return
                ;;
            esac
        ;;
    esac;
    $split &amp;&amp; return;
    if [[ &quot;$cur&quot; == -* ]]; then
        COMPREPLY=($( compgen -W &quot;$( LC_ALL=C $1 --help 2&gt;&amp;1 |             command sed -ne &apos;s/.*\(--[-A-Za-z0-9]\{1,\}=\{0,1\}\).*/\1/p&apos; | sort -u )&quot;             -- &quot;$cur&quot; ));
        [[ $COMPREPLY == *= ]] &amp;&amp; compopt -o nospace;
    else
        if [[ &quot;$1&quot; == @(rmdir|chroot) ]]; then
            _filedir -d;
        else
            [[ &quot;$1&quot; == mkdir ]] &amp;&amp; compopt -o nospace;
            _filedir;
        fi;
    fi
}
_mac_addresses () 
{ 
    local re=&apos;\([A-Fa-f0-9]\{2\}:\)\{5\}[A-Fa-f0-9]\{2\}&apos;;
    local PATH=&quot;$PATH:/sbin:/usr/sbin&quot;;
    COMPREPLY+=($(         { LC_ALL=C ifconfig -a || ip link show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]HWaddr[[:space:]]\{1,\}\($re\)[[:space:]]*$/\1/p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]].*|\2|p&quot; -ne         &quot;s|.*[[:space:]]\(link/\)\{0,1\}ether[[:space:]]\{1,\}\($re\)[[:space:]]*$|\2|p&quot;
        ));
    COMPREPLY+=($( { arp -an || ip neigh show; } 2&gt;/dev/null | command sed -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]].*/\1/p&quot; -ne         &quot;s/.*[[:space:]]\($re\)[[:space:]]*$/\1/p&quot; ));
    COMPREPLY+=($( command sed -ne         &quot;s/^[[:space:]]*\($re\)[[:space:]].*/\1/p&quot; /etc/ethers 2&gt;/dev/null ));
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]}&apos; -- &quot;$cur&quot; ));
    __ltrim_colon_completions &quot;$cur&quot;
}
_minimal () 
{ 
    local cur prev words cword split;
    _init_completion -s || return;
    $split &amp;&amp; return;
    _filedir
}
_modules () 
{ 
    local modpath;
    modpath=/lib/modules/$1;
    COMPREPLY=($( compgen -W &quot;$( command ls -RL $modpath 2&gt;/dev/null |         command sed -ne &apos;s/^\(.*\)\.k\{0,1\}o\(\.[gx]z\)\{0,1\}$/\1/p&apos; )&quot; -- &quot;$cur&quot; ))
}
_ncpus () 
{ 
    local var=NPROCESSORS_ONLN;
    [[ $OSTYPE == *linux* ]] &amp;&amp; var=_$var;
    local n=$( getconf $var 2&gt;/dev/null );
    printf %s ${n:-1}
}
_parse_help () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---help} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        [[ $line == *([[:blank:]])-* ]] || continue;
        while [[ $line =~ ((^|[^-])-[A-Za-z0-9?][[:space:]]+)\[?[A-Z0-9]+\]? ]]; do
            line=${line/&quot;${BASH_REMATCH[0]}&quot;/&quot;${BASH_REMATCH[1]}&quot;};
        done;
        __parse_options &quot;${line// or /, }&quot;;
    done
}
_parse_usage () 
{ 
    eval local cmd=$( quote &quot;$1&quot; );
    local line match option i char;
    { 
        case $cmd in 
            -)
                cat
            ;;
            *)
                LC_ALL=C &quot;$( dequote &quot;$cmd&quot; )&quot; ${2:---usage} 2&gt;&amp;1
            ;;
        esac
    } | while read -r line; do
        while [[ $line =~ \[[[:space:]]*(-[^]]+)[[:space:]]*\] ]]; do
            match=${BASH_REMATCH[0]};
            option=${BASH_REMATCH[1]};
            case $option in 
                -?(\[)+([a-zA-Z0-9?]))
                    for ((i=1; i &lt; ${#option}; i++ ))
                    do
                        char=${option:i:1};
                        [[ $char != &apos;[&apos; ]] &amp;&amp; printf &apos;%s\n&apos; -$char;
                    done
                ;;
                *)
                    __parse_options &quot;$option&quot;
                ;;
            esac;
            line=${line#*&quot;$match&quot;};
        done;
    done
}
_pci_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lspci -n | awk &apos;{print $3}&apos;)&quot; -- &quot;$cur&quot; ))
}
_pgids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pgid= )&apos; -- &quot;$cur&quot; ))
}
_pids () 
{ 
    COMPREPLY=($( compgen -W &apos;$( command ps axo pid= )&apos; -- &quot;$cur&quot; ))
}
_pnames () 
{ 
    if [[ &quot;$1&quot; == -s ]]; then
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos;             -W &apos;$( command ps axo comm | command sed -e 1d )&apos; -- &quot;$cur&quot; ));
    else
        COMPREPLY=($( compgen -X &apos;&lt;defunct&gt;&apos; -W &apos;$( command ps axo command= | command sed -e \
            &quot;s/ .*//&quot; -e \
            &quot;s:.*/::&quot; -e \
            &quot;s/:$//&quot; -e \
            &quot;s/^[[(-]//&quot; -e \
            &quot;s/[])]$//&quot; | sort -u )&apos; -- &quot;$cur&quot; ));
    fi
}
_quote_readline_by_ref () 
{ 
    if [ -z &quot;$1&quot; ]; then
        printf -v $2 %s &quot;$1&quot;;
    else
        if [[ $1 == \&apos;* ]]; then
            printf -v $2 %s &quot;${1:1}&quot;;
        else
            if [[ $1 == ~* ]]; then
                printf -v $2 ~%q &quot;${1:1}&quot;;
            else
                printf -v $2 %q &quot;$1&quot;;
            fi;
        fi;
    fi;
    [[ ${!2} == \$* ]] &amp;&amp; eval $2=${!2}
}
_realcommand () 
{ 
    type -P &quot;$1&quot; &gt; /dev/null &amp;&amp; { 
        if type -p realpath &gt; /dev/null; then
            realpath &quot;$(type -P &quot;$1&quot;)&quot;;
        else
            if type -p greadlink &gt; /dev/null; then
                greadlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
            else
                if type -p readlink &gt; /dev/null; then
                    readlink -f &quot;$(type -P &quot;$1&quot;)&quot;;
                else
                    type -P &quot;$1&quot;;
                fi;
            fi;
        fi
    }
}
_rl_enabled () 
{ 
    [[ &quot;$( bind -v )&quot; == *$1+([[:space:]])on* ]]
}
_root_command () 
{ 
    local PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin;
    local root_command=$1;
    _command
}
_service () 
{ 
    local cur prev words cword;
    _init_completion || return;
    [[ $cword -gt 2 ]] &amp;&amp; return;
    if [[ $cword -eq 1 &amp;&amp; $prev == ?(*/)service ]]; then
        _services;
        [[ -e /etc/mandrake-release ]] &amp;&amp; _xinetd_services;
    else
        local sysvdirs;
        _sysvdirs;
        COMPREPLY=($( compgen -W &apos;`command sed -e &quot;y/|/ /&quot; \
            -ne &quot;s/^.*\(U\|msg_u\)sage.*{\(.*\)}.*$/\2/p&quot; \
            ${sysvdirs[0]}/${prev##*/} 2&gt;/dev/null` start stop&apos; -- &quot;$cur&quot; ));
    fi
}
_services () 
{ 
    local sysvdirs;
    _sysvdirs;
    local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
    shopt -s nullglob;
    COMPREPLY=($( printf &apos;%s\n&apos; ${sysvdirs[0]}/!($_backup_glob|functions|README) ));
    $reset;
    COMPREPLY+=($( systemctl list-units --full --all 2&gt;/dev/null |         awk &apos;$1 ~ /\.service$/ { sub(&quot;\\.service$&quot;, &quot;&quot;, $1); print $1 }&apos; ));
    if [[ -x /sbin/upstart-udev-bridge ]]; then
        COMPREPLY+=($( initctl list 2&gt;/dev/null | cut -d&apos; &apos; -f1 ));
    fi;
    COMPREPLY=($( compgen -W &apos;${COMPREPLY[@]#${sysvdirs[0]}/}&apos; -- &quot;$cur&quot; ))
}
_shells () 
{ 
    local shell rest;
    while read -r shell rest; do
        [[ $shell == /* &amp;&amp; $shell == &quot;$cur&quot;* ]] &amp;&amp; COMPREPLY+=($shell);
    done 2&gt; /dev/null &lt; /etc/shells
}
_signals () 
{ 
    local -a sigs=($( compgen -P &quot;$1&quot; -A signal &quot;SIG${cur#$1}&quot; ));
    COMPREPLY+=(&quot;${sigs[@]/#${1}SIG/${1}}&quot;)
}
_split_longopt () 
{ 
    if [[ &quot;$cur&quot; == --?*=* ]]; then
        prev=&quot;${cur%%?(\\)=*}&quot;;
        cur=&quot;${cur#*=}&quot;;
        return 0;
    fi;
    return 1
}
_sysvdirs () 
{ 
    sysvdirs=();
    [[ -d /etc/rc.d/init.d ]] &amp;&amp; sysvdirs+=(/etc/rc.d/init.d);
    [[ -d /etc/init.d ]] &amp;&amp; sysvdirs+=(/etc/init.d);
    [[ -f /etc/slackware-version ]] &amp;&amp; sysvdirs=(/etc/rc.d)
}
_terms () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( command sed -ne &apos;s/^\([^[:space:]#|]\{2,\}\)|.*/\1/p&apos; /etc/termcap             2&gt;/dev/null )&quot; -- &quot;$cur&quot; ));
    COMPREPLY+=($( compgen -W &quot;$( { toe -a 2&gt;/dev/null || toe 2&gt;/dev/null; }         | awk &apos;{ print $1 }&apos; | sort -u )&quot; -- &quot;$cur&quot; ))
}
_tilde () 
{ 
    local result=0;
    if [[ $1 == \~* &amp;&amp; $1 != */* ]]; then
        COMPREPLY=($( compgen -P &apos;~&apos; -u -- &quot;${1#\~}&quot; ));
        result=${#COMPREPLY[@]};
        [[ $result -gt 0 ]] &amp;&amp; compopt -o filenames 2&gt; /dev/null;
    fi;
    return $result
}
_uids () 
{ 
    if type getent &amp;&gt; /dev/null; then
        COMPREPLY=($( compgen -W &apos;$( getent passwd | cut -d: -f3 )&apos; -- &quot;$cur&quot; ));
    else
        if type perl &amp;&gt; /dev/null; then
            COMPREPLY=($( compgen -W &apos;$( perl -e &apos;&quot;&apos;&quot;&apos;while (($uid) = (getpwent)[2]) { print $uid . &quot;\n&quot; }&apos;&quot;&apos;&quot;&apos; )&apos; -- &quot;$cur&quot; ));
        else
            COMPREPLY=($( compgen -W &apos;$( cut -d: -f3 /etc/passwd )&apos; -- &quot;$cur&quot; ));
        fi;
    fi
}
_upvar () 
{ 
    if unset -v &quot;$1&quot;; then
        if (( $# == 2 )); then
            eval $1=\&quot;\$2\&quot;;
        else
            eval $1=\(\&quot;\${@:2}\&quot;\);
        fi;
    fi
}
_upvars () 
{ 
    if ! (( $# )); then
        echo &quot;${FUNCNAME[0]}: usage: ${FUNCNAME[0]} [-v varname&quot; &quot;value] | [-aN varname [value ...]] ...&quot; 1&gt;&amp;2;
        return 2;
    fi;
    while (( $# )); do
        case $1 in 
            -a*)
                [[ -n ${1#-a} ]] || { 
                    echo &quot;bash: ${FUNCNAME[0]}: \`$1&apos;: missing&quot; &quot;number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                printf %d &quot;${1#-a}&quot; &amp;&gt; /dev/null || { 
                    echo &quot;bash:&quot; &quot;${FUNCNAME[0]}: \`$1&apos;: invalid number specifier&quot; 1&gt;&amp;2;
                    return 1
                };
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\(\&quot;\${@:3:${1#-a}}\&quot;\) &amp;&amp; shift $((${1#-a} + 2)) || { 
                    echo &quot;bash: ${FUNCNAME[0]}:&quot; &quot;\`$1${2+ }$2&apos;: missing argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            -v)
                [[ -n &quot;$2&quot; ]] &amp;&amp; unset -v &quot;$2&quot; &amp;&amp; eval $2=\&quot;\$3\&quot; &amp;&amp; shift 3 || { 
                    echo &quot;bash: ${FUNCNAME[0]}: $1: missing&quot; &quot;argument(s)&quot; 1&gt;&amp;2;
                    return 1
                }
            ;;
            *)
                echo &quot;bash: ${FUNCNAME[0]}: $1: invalid option&quot; 1&gt;&amp;2;
                return 1
            ;;
        esac;
    done
}
_usb_ids () 
{ 
    COMPREPLY+=($( compgen -W         &quot;$( PATH=&quot;$PATH:/sbin&quot; lsusb | awk &apos;{print $6}&apos; )&quot; -- &quot;$cur&quot; ))
}
_user_at_host () 
{ 
    local cur prev words cword;
    _init_completion -n : || return;
    if [[ $cur == *@* ]]; then
        _known_hosts_real &quot;$cur&quot;;
    else
        COMPREPLY=($( compgen -u -S @ -- &quot;$cur&quot; ));
        compopt -o nospace;
    fi
}
_usergroup () 
{ 
    if [[ $cur == *\\\\* || $cur == *:*:* ]]; then
        return;
    else
        if [[ $cur == *\\:* ]]; then
            local prefix;
            prefix=${cur%%*([^:])};
            prefix=${prefix//\\};
            local mycur=&quot;${cur#*[:]}&quot;;
            if [[ $1 == -u ]]; then
                _allowed_groups &quot;$mycur&quot;;
            else
                local IFS=&apos;
&apos;;
                COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
            fi;
            COMPREPLY=($( compgen -P &quot;$prefix&quot; -W &quot;${COMPREPLY[@]}&quot; ));
        else
            if [[ $cur == *:* ]]; then
                local mycur=&quot;${cur#*:}&quot;;
                if [[ $1 == -u ]]; then
                    _allowed_groups &quot;$mycur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -g -- &quot;$mycur&quot; ));
                fi;
            else
                if [[ $1 == -u ]]; then
                    _allowed_users &quot;$cur&quot;;
                else
                    local IFS=&apos;
&apos;;
                    COMPREPLY=($( compgen -u -- &quot;$cur&quot; ));
                fi;
            fi;
        fi;
    fi
}
_userland () 
{ 
    local userland=$( uname -s );
    [[ $userland == @(Linux|GNU/*) ]] &amp;&amp; userland=GNU;
    [[ $userland == $1 ]]
}
_variables () 
{ 
    if [[ $cur =~ ^(\$(\{[!#]?)?)([A-Za-z0-9_]*)$ ]]; then
        if [[ $cur == \${* ]]; then
            local arrs vars;
            vars=($( compgen -A variable -P ${BASH_REMATCH[1]} -S &apos;}&apos; -- ${BASH_REMATCH[3]} )) &amp;&amp; arrs=($( compgen -A arrayvar -P ${BASH_REMATCH[1]} -S &apos;[&apos; -- ${BASH_REMATCH[3]} ));
            if [[ ${#vars[@]} -eq 1 &amp;&amp; -n $arrs ]]; then
                compopt -o nospace;
                COMPREPLY+=(${arrs[*]});
            else
                COMPREPLY+=(${vars[*]});
            fi;
        else
            COMPREPLY+=($( compgen -A variable -P &apos;$&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
        fi;
        return 0;
    else
        if [[ $cur =~ ^(\$\{[#!]?)([A-Za-z0-9_]*)\[([^]]*)$ ]]; then
            local IFS=&apos;
&apos;;
            COMPREPLY+=($( compgen -W &apos;$(printf %s\\n &quot;${!&apos;${BASH_REMATCH[2]}&apos;[@]}&quot;)&apos;             -P &quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[&quot; -S &apos;]}&apos; -- &quot;${BASH_REMATCH[3]}&quot; ));
            if [[ ${BASH_REMATCH[3]} == [@*] ]]; then
                COMPREPLY+=(&quot;${BASH_REMATCH[1]}${BASH_REMATCH[2]}[${BASH_REMATCH[3]}]}&quot;);
            fi;
            __ltrim_colon_completions &quot;$cur&quot;;
            return 0;
        else
            if [[ $cur =~ ^\$\{[#!]?[A-Za-z0-9_]*\[.*\]$ ]]; then
                COMPREPLY+=(&quot;$cur}&quot;);
                __ltrim_colon_completions &quot;$cur&quot;;
                return 0;
            else
                case $prev in 
                    TZ)
                        cur=/usr/share/zoneinfo/$cur;
                        _filedir;
                        for i in ${!COMPREPLY[@]};
                        do
                            if [[ ${COMPREPLY[i]} == *.tab ]]; then
                                unset &apos;COMPREPLY[i]&apos;;
                                continue;
                            else
                                if [[ -d ${COMPREPLY[i]} ]]; then
                                    COMPREPLY[i]+=/;
                                    compopt -o nospace;
                                fi;
                            fi;
                            COMPREPLY[i]=${COMPREPLY[i]#/usr/share/zoneinfo/};
                        done;
                        return 0
                    ;;
                esac;
            fi;
        fi;
    fi;
    return 1
}
_xfunc () 
{ 
    set -- &quot;$@&quot;;
    local srcfile=$1;
    shift;
    declare -F $1 &amp;&gt; /dev/null || { 
        __load_completion &quot;$srcfile&quot;
    };
    &quot;$@&quot;
}
_xinetd_services () 
{ 
    local xinetddir=/etc/xinetd.d;
    if [[ -d $xinetddir ]]; then
        local IFS=&apos; 	
&apos; reset=$(shopt -p nullglob);
        shopt -s nullglob;
        local -a svcs=($( printf &apos;%s\n&apos; $xinetddir/!($_backup_glob) ));
        $reset;
        COMPREPLY+=($( compgen -W &apos;${svcs[@]#$xinetddir/}&apos; -- &quot;$cur&quot; ));
    fi
}
dequote () 
{ 
    eval printf %s &quot;$1&quot; 2&gt; /dev/null
}
quote () 
{ 
    local quoted=${1//\&apos;/\&apos;\\\&apos;\&apos;};
    printf &quot;&apos;%s&apos;&quot; &quot;$quoted&quot;
}
quote_readline () 
{ 
    local quoted;
    _quote_readline_by_ref &quot;$1&quot; ret;
    printf %s &quot;$ret&quot;
}
<font color="#EF2929"><b>root@root</b></font>:<font color="#729FCF"><b>~</b></font># 
</pre>
)
	{
	}
}
Hello World!");
        }
    }
}
